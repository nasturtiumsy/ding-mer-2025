import { Component, OnInit } from '@angular/core';
import * as XLSX from 'xlsx';
import { SettlementService } from '../services/settlement.service';
import { BusinessService } from '../services/business.service';

@Component({
  selector: 'app-settlement',
  templateUrl: './settlement.page.html',
  styleUrls: ['./settlement.page.scss'],
  standalone: false,
})
export class SettlementPage implements OnInit {
  // Date Range Filters
  today = new Date().toISOString().split('T')[0]; // Today's date in YYYY-MM-DD format
  startDate: string = this.today; // Default to today
  endDate: string = this.today;   // Default to today

  // Search Query
  searchQuery: string = '';

  // Settlement Data
  settlements: any[] = [];
  filteredSettlements: any[] = [];

  // Sorting
  sortColumn: string = 'Date'; // Default sorting column
  sortOrder: string = 'asc';   // Default sorting order

  constructor(
    private settlementService: SettlementService,
    private businessService: BusinessService
  ) { }

  ngOnInit() {
    this.loadInitialData();
  }

  loadInitialData() {
    // Fetch settlements
    this.settlements = this.settlementService.getSettlements();

    // Apply initial filters
    this.applyFilters();
  }

  applyFilters() {
    // Fetch settlements based on filters
    const filteredSettlements = this.settlements.filter((settlement) => {
      const settlementDate = new Date(settlement.Date);

      // Apply date range filter
      if (this.startDate && settlementDate < new Date(this.startDate)) return false;
      if (this.endDate && settlementDate > new Date(this.endDate)) return false;

      // Apply search filter
      const searchableFields = [
        settlement.SettlementID,
        this.getBankAccount(settlement.BusinessID),
        settlement.Amount.toString(),
      ].join(' ').toLowerCase();

      if (this.searchQuery && !searchableFields.includes(this.searchQuery.toLowerCase())) return false;

      return true;
    });

    // Sort settlements
    this.filteredSettlements = this.sortSettlements(filteredSettlements);
  }

  sortSettlements(settlements: any[]): any[] {
    return [...settlements].sort((a, b) => {
      const valA = a[this.sortColumn];
      const valB = b[this.sortColumn];

      if (this.sortOrder === 'asc') {
        return typeof valA === 'string' ? valA.localeCompare(valB) : valA - valB;
      } else {
        return typeof valA === 'string' ? valB.localeCompare(valA) : valB - valA;
      }
    });
  }

  sort(column: string) {
    if (this.sortColumn === column) {
      // Cycle through sorting orders: asc -> desc -> asc
      this.sortOrder = this.sortOrder === 'asc' ? 'desc' : 'asc';
    } else {
      // Set new column and reset to ascending
      this.sortColumn = column;
      this.sortOrder = 'asc';
    }

    this.applyFilters();
  }

  getSortIndicator(column: string): string {
    if (this.sortColumn === column) {
      return this.sortOrder === 'asc' ? '↑' : '↓';
    }
    return '';
  }

  previousPage() {
    // Implement pagination logic
  }

  nextPage() {
    // Implement pagination logic
  }

  // Helper Functions
  getBankAccount(businessID: string): string {
    const business = this.businessService.getBusinessByID(businessID);
    return business ? business.BankAccount : 'Unknown Bank Account';
  }

  downloadExcel() {
    const worksheetData = [
      ['Date', 'Time', 'Bank Account', 'Reference', 'Amount ($)'], // Table headers
      ...this.filteredSettlements.map((settlement) => [
        settlement.Date,
        settlement.Time,
        this.getBankAccount(settlement.BusinessID),
        settlement.SettlementID,
        settlement.Amount.toFixed(2),
      ]),
    ];

    const worksheet = XLSX.utils.aoa_to_sheet(worksheetData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Settlements');
    XLSX.writeFile(workbook, 'settlement_report.xlsx');
  }
}
