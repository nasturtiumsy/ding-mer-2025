import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ModalController } from '@ionic/angular';
import { ForgotPasswordModalComponent } from '../forgot-password-modal/forgot-password-modal.component';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
  standalone: false,
})
export class LoginPage implements OnInit {
  email: string = '';
  password: string = '';
  constructor(private router: Router, private modalController: ModalController) { }

  // Simulate login and redirect to Home
  login() {
    console.log('Logging in with:', this.email, this.password);

    // Basic validation
    if (!this.email || !this.password) {
      console.log('Please enter both email and password.');
      return;
    }

    // Simulate successful login
    console.log('User logged in successfully');
    this.router.navigate(['home']);
  }

  // Open Forgot Password Modal
  async openForgotPasswordModal() {
    const modal = await this.modalController.create({
      component: ForgotPasswordModalComponent,
    });
    return await modal.present();
  }

  ngOnInit() {
  }

}
