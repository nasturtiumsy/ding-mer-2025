import { Component, OnInit } from '@angular/core';
import { TransactionService } from '../services/transaction.service';
import { BranchService } from '../services/branch.service';
import { TerminalService } from '../services/terminal.service';
import * as XLSX from 'xlsx';

@Component({
  selector: 'app-statement',
  templateUrl: './statement.page.html',
  styleUrls: ['./statement.page.scss'],
  standalone: false,
})
export class StatementPage implements OnInit {
  // Metrics
  totalSales = 0;
  reversedSales = 0;

  // Date Range Filters
  today = new Date().toISOString().split('T')[0]; // Today's date in YYYY-MM-DD format
  startDate: string = this.today; // Default to today
  endDate: string = this.today;   // Default to today

  // Branches and Terminals
  branches: any[] = [];
  terminals: any[] = [];
  selectedBranch: string = 'all'; // Default to "All Branches"
  selectedTerminal: string = 'all'; // Default to "All Terminals"

  // Search Query
  searchQuery: string = '';

  // Transactions
  transactions: any[] = [];
  filteredTransactions: any[] = [];

  // Sorting
  sortColumn: string = 'Date'; // Default sorting column
  sortOrder: string = 'desc';   // Default sorting order (descending)

  constructor(
    private transactionService: TransactionService,
    private branchService: BranchService,
    private terminalService: TerminalService
  ) { }

  ngOnInit() {
    this.loadInitialData();
  }

  loadInitialData() {
    // Fetch branches and terminals
    this.branches = this.branchService.getBranches();
    this.terminals = this.terminalService.getTerminals();

    // Fetch transactions
    this.transactions = this.transactionService.getTransactions().map((txn) => ({
      ...txn,
      Amount: txn.TransactionType === 'Refund' ? -txn.Amount : txn.Amount, // Make refunds negative
    }));

    // Apply initial filters
    this.applyFilters();
  }

  applyFilters() {
    // Fetch transactions based on filters
    const filteredTransactions = this.transactions
      .filter((txn) => {
        const txnDate = new Date(txn.Date);

        // Apply date range filter
        if (this.startDate && txnDate < new Date(this.startDate)) return false;
        if (this.endDate && txnDate > new Date(this.endDate)) return false;

        // Apply branch filter
        if (this.selectedBranch !== 'all' && txn.BranchID !== this.selectedBranch) return false;

        // Apply terminal filter
        if (this.selectedTerminal !== 'all' && txn.TerminalID !== this.selectedTerminal) return false;

        // Apply search filter
        const searchableFields = [
          txn.TransactionID,
          this.getBranchName(txn.BranchID),
          this.getTerminalName(txn.TerminalID),
          txn.PhoneNumber,
          Math.abs(txn.Amount).toString(),
        ].join(' ').toLowerCase();

        if (this.searchQuery && !searchableFields.includes(this.searchQuery.toLowerCase())) return false;

        return true;
      })
      .map((txn) => ({
        ...txn,
        BranchName: this.getBranchName(txn.BranchID), // Add BranchName to the transaction object
        TerminalName: this.getTerminalName(txn.TerminalID), // Add TerminalName to the transaction object
      }));

    // Sort transactions
    this.filteredTransactions = this.sortTransactions(filteredTransactions);

    // Calculate metrics
    this.totalSales = filteredTransactions.reduce((sum, txn) => {
      if (txn.TransactionType === 'Sale') {
        return sum + txn.Amount;
      }
      return sum;
    }, 0);

    this.reversedSales = filteredTransactions.reduce((sum, txn) => {
      if (txn.TransactionType === 'Refund') {
        return sum + txn.Amount; // Already negative for refunds
      }
      return sum;
    }, 0);
  }

  sortTransactions(transactions: any[]): any[] {
    return [...transactions].sort((a, b) => {
      const valA = a[this.sortColumn];
      const valB = b[this.sortColumn];

      if (this.sortOrder === 'asc') {
        return typeof valA === 'string' ? valA.localeCompare(valB) : valA - valB;
      } else {
        return typeof valA === 'string' ? valB.localeCompare(valA) : valB - valA;
      }
    });
  }

  sort(column: string) {
    if (this.sortColumn === column) {
      // Cycle through sorting orders: asc -> desc -> asc
      this.sortOrder = this.sortOrder === 'asc' ? 'desc' : 'asc';
    } else {
      // Set new column and reset to ascending
      this.sortColumn = column;
      this.sortOrder = 'asc';
    }

    this.applyFilters();
  }

  getSortIndicator(column: string): string {
    if (this.sortColumn === column) {
      return this.sortOrder === 'asc' ? '↑' : '↓';
    }
    return '';
  }

  previousPage() {
    // Implement pagination logic
  }

  nextPage() {
    // Implement pagination logic
  }

  // Helper Functions
  getBranchName(branchID: string): string {
    const branch = this.branches.find((b) => b.BranchID === branchID);
    return branch ? branch.Name : 'Unknown Branch';
  }

  getTerminalName(terminalID: string): string {
    const terminal = this.terminals.find((t) => t.TerminalID === terminalID);
    return terminal ? terminal.Name : 'Unknown Terminal';
  }

  downloadExcel() {
    const worksheetData = [
      ['Date', 'Time', 'Branch', 'Terminal', 'Phone Number', 'Reference', 'Amount ($)'], // Table headers
      ...this.filteredTransactions.map((txn) => [
        txn.Date,
        txn.Time,
        this.getBranchName(txn.BranchID),
        this.getTerminalName(txn.TerminalID),
        txn.PhoneNumber,
        txn.TransactionID,
        txn.Amount.toFixed(2),
      ]),
    ];

    const worksheet = XLSX.utils.aoa_to_sheet(worksheetData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Transactions');
    XLSX.writeFile(workbook, 'transaction_report.xlsx');
  }
}



