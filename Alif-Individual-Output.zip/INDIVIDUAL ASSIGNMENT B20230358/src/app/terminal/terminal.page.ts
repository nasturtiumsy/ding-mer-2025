import { Component, OnInit } from '@angular/core';
import { TerminalService } from '../services/terminal.service';
import { BranchService } from '../services/branch.service';
import * as QRCode from 'qrcode';

@Component({
  selector: 'app-terminal',
  templateUrl: './terminal.page.html',
  styleUrls: ['./terminal.page.scss'],
  standalone: false,
})
export class TerminalPage implements OnInit {
  terminals: any[] = [];
  branches: any[] = [];

  constructor(
    private terminalService: TerminalService,
    private branchService: BranchService
  ) { }

  ngOnInit() {
    this.loadTerminals();
    this.loadBranches();
  }

  loadTerminals() {
    // Fetch terminals from the service
    this.terminals = this.terminalService.getTerminals();
  }

  loadBranches() {
    // Fetch branches from the service
    this.branches = this.branchService.getBranches();
  }

  getBranchName(branchID: string): string {
    const branch = this.branches.find((b) => b.BranchID === branchID);
    return branch ? branch.Name : 'Unknown Branch';
  }

  async downloadQRCode(terminalLink: string, terminalName: string) {
    try {
      // Generate QR code as a data URL
      const qrCodeDataUrl = await QRCode.toDataURL(terminalLink);

      // Create a temporary anchor element to trigger the download
      const link = document.createElement('a');
      link.href = qrCodeDataUrl;
      link.download = `${terminalName.replace(/\s+/g, '_')}_QRCode.png`; // File name
      link.click();

      console.log(`QR Code downloaded for terminal: ${terminalName}`);
    } catch (error) {
      console.error('Error generating or downloading QR code:', error);
    }
  }
}