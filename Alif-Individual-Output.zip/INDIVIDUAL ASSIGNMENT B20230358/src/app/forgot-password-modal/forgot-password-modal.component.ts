import { Component, OnInit } from '@angular/core';
import { IonInput } from "@ionic/angular/standalone";
import { ModalController } from '@ionic/angular';


@Component({
  selector: 'app-forgot-password-modal',
  templateUrl: './forgot-password-modal.component.html',
  styleUrls: ['./forgot-password-modal.component.scss'],
  standalone: false,
})
export class ForgotPasswordModalComponent implements OnInit {
  email: string = '';
  otp: string = '';
  otpSent: boolean = false; // Tracks whether OTP has been sent
  timeLeft: number = 180; // Countdown starts at 3 minutes (180 seconds)
  interval: any; // Stores the interval timer
  constructor(private modalController: ModalController) { }

  // Close the modal
  dismissModal() {
    this.modalController.dismiss();
  }

  // Send OTP and start countdown
  sendOTP() {
    if (!this.email) {
      alert('Please enter a valid email.');
      return;
    }

    console.log('Sending OTP to:', this.email);

    // Simulate OTP being sent
    alert('OTP sent to your email.');

    // Show OTP input and start countdown
    this.otpSent = true;
    this.startCountdown();
  }

  // Start the countdown timer
  startCountdown() {
    this.interval = setInterval(() => {
      if (this.timeLeft > 0) {
        this.timeLeft--;
      } else {
        clearInterval(this.interval); // Stop the timer when it reaches 0
      }
    }, 1000);
  }

  // Verify OTP
  verifyOTP() {
    if (!this.otp) {
      alert('Please enter the OTP.');
      return;
    }

    console.log('Verifying OTP:', this.otp);

    // Simulate OTP verification
    alert('OTP verified successfully.');

    // Close the modal after submission
    this.modalController.dismiss();
  }

  ngOnInit() { }

}
