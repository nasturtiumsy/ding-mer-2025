import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SettlementService {
  private settlements = [
    {
      SettlementID: 'settle_001',
      BusinessID: 'biz_12345',
      Date: '2025-04-11', // Friday (settles Thursday's transactions)
      Time: '17:00:00',
      TransactionDirection: 'Incoming',
      Amount: 98.0, // Net amount after MDR (100 - 2%)
      SettlementStatus: 'Success',
    },
    {
      SettlementID: 'settle_002',
      BusinessID: 'biz_12345',
      Date: '2025-04-14', // Monday (settles Saturday and Sunday's transactions)
      Time: '17:00:00',
      TransactionDirection: 'Incoming',
      Amount: 264.6, // Net amount after MDR (200 + 75 - 2% of each)
      SettlementStatus: 'Success',
    },
  ];

  getSettlements() {
    return this.settlements;
  }

  calculateNetAmount(grossAmount: number, mdrRate: number = 0.02): number {
    return grossAmount * (1 - mdrRate);
  }
}
