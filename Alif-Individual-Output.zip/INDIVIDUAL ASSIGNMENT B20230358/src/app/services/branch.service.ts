import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class BranchService {
  private branches = [
    {
      BranchID: 'branch_123',
      BusinessID: 'biz_12345',
      Name: 'Main Branch',
      Address: '123 Merchant St',
      PhoneNumber: '+6738226223',
      Email: 'mainbranch@example.com',
      IsActive: true,
    },
    {
      BranchID: 'branch_456',
      BusinessID: 'biz_12345',
      Name: 'Secondary Branch',
      Address: '456 Merchant St',
      PhoneNumber: '+6738226224',
      Email: 'secondarybranch@example.com',
      IsActive: true,
    },
  ];

  getBranches() {
    return this.branches;
  }
}
