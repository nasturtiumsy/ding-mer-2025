import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class TransactionService {
  private transactions = [
    {
      TransactionID: 'txn_001',
      TransactionDirection: 'Incoming',
      Date: '2025-04-10', // Thursday
      Time: '14:30:00',
      Amount: 100.0,
      PhoneNumber: '+6738226223',
      TerminalID: 'term_9876',
      BranchID: 'branch_123',
      TransactionType: 'Sale',
      TransactionStatus: 'Success',
    },
    {
      TransactionID: 'txn_002',
      TransactionDirection: 'Incoming',
      Date: '2025-04-11', // Friday
      Time: '10:15:00',
      Amount: 50.0,
      PhoneNumber: '+6738226224',
      TerminalID: 'term_9876',
      BranchID: 'branch_123',
      TransactionType: 'Refund',
      TransactionStatus: 'Success',
    },
    {
      TransactionID: 'txn_003',
      TransactionDirection: 'Incoming',
      Date: '2025-04-12', // Saturday
      Time: '16:45:00',
      Amount: 200.0,
      PhoneNumber: '+6738226225',
      TerminalID: 'term_1234',
      BranchID: 'branch_456',
      TransactionType: 'Sale',
      TransactionStatus: 'Success',
    },
    {
      TransactionID: 'txn_004',
      TransactionDirection: 'Incoming',
      Date: '2025-04-13', // Sunday
      Time: '09:00:00',
      Amount: 75.0,
      PhoneNumber: '+6738226226',
      TerminalID: 'term_1234',
      BranchID: 'branch_456',
      TransactionType: 'Sale',
      TransactionStatus: 'Failed',
    },
    {
      TransactionID: 'txn_005',
      TransactionDirection: 'Incoming',
      Date: '2025-04-07', // Last Week
      Time: '14:30:00',
      Amount: 100.0,
      PhoneNumber: '+6738226223',
      TerminalID: 'term_9876',
      BranchID: 'branch_123',
      TransactionType: 'Sale',
      TransactionStatus: 'Success',
    },
    {
      TransactionID: 'txn_006',
      TransactionDirection: 'Incoming',
      Date: '2025-03-15', // Last Month
      Time: '10:15:00',
      Amount: 50.0,
      PhoneNumber: '+6738226224',
      TerminalID: 'term_9876',
      BranchID: 'branch_123',
      TransactionType: 'Refund',
      TransactionStatus: 'Success',
    },
    {
      TransactionID: 'txn_007',
      TransactionDirection: 'Incoming',
      Date: '2025-04-14', // Last Week
      Time: '14:30:00',
      Amount: 531.0,
      PhoneNumber: '+6738226223',
      TerminalID: 'term_9876',
      BranchID: 'branch_123',
      TransactionType: 'Sale',
      TransactionStatus: 'Success',
    },
    {
      TransactionID: 'txn_008',
      TransactionDirection: 'Incoming',
      Date: '2025-03-12', // Last Month
      Time: '10:15:00',
      Amount: 220.0,
      PhoneNumber: '+6738226224',
      TerminalID: 'term_9876',
      BranchID: 'branch_123',
      TransactionType: 'Sale',
      TransactionStatus: 'Success',
    },
    {
      TransactionID: 'txn_009',
      TransactionDirection: 'Incoming',
      Date: '2025-04-13', // Last Week
      Time: '14:30:00',
      Amount: 23.0,
      PhoneNumber: '+6738226223',
      TerminalID: 'term_9876',
      BranchID: 'branch_123',
      TransactionType: 'Sale',
      TransactionStatus: 'Success',
    },
  ];

  getTransactions() {
    return this.transactions;
  }

  filterTransactions(filters: any) {
    // Simulate filtering logic
    return this.transactions.filter((txn) => {
      if (filters.date && txn.Date !== filters.date) return false;
      if (filters.branchId && txn.BranchID !== filters.branchId) return false;
      if (filters.transactionType && txn.TransactionType !== filters.transactionType) return false;
      return true;
    });
  }
}
