import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class TerminalService {
  private terminals = [
    {
      TerminalID: 'term_9876',
      BranchID: 'branch_123',
      Name: 'Main Terminal',
      Link: 'https://www.google.com',
      Location: 'Front Desk',
      IsActive: true,
    },
    {
      TerminalID: 'term_1234',
      BranchID: 'branch_456',
      Name: 'Secondary Terminal',
      Link: 'https://qr.example.com/term_1234',
      Location: 'Back Office',
      IsActive: true,
    },
  ];

  getTerminals() {
    return this.terminals;
  }
}
