import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class BusinessService {
  private business = {
    BusinessID: 'biz_12345',
    BusinessName: 'Example Merchant Co.', // Added BusinessName
    LogoImage: 'assets/business-logo.png',
    Address: '123 Merchant St',
    PhoneNumber: '+6738226223',
    Email: 'info@example.com',
    BankName: 'BIBD',
    BankAccount: '00001010112488',
  };

  getBusinessDetails() {
    return this.business;
  }
  getBusinessByID(businessID: string) {
    // Compare the BusinessID directly
    return this.business.BusinessID === businessID ? this.business : null;
  }
}
