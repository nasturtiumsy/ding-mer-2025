import { Component, OnInit } from '@angular/core';
import { BranchService } from '../services/branch.service';

@Component({
  selector: 'app-branch',
  templateUrl: './branch.page.html',
  styleUrls: ['./branch.page.scss'],
  standalone: false,
})
export class BranchPage implements OnInit {
  branches: any[] = [];

  constructor(private branchService: BranchService) { }

  ngOnInit() {
    this.loadBranches();
  }

  loadBranches() {
    // Fetch branches from the service
    this.branches = this.branchService.getBranches();
  }
}
