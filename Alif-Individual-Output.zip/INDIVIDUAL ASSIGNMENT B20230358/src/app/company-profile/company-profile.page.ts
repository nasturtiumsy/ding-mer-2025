import { Component, OnInit } from '@angular/core';
import { BusinessService } from '../services/business.service';

@Component({
  selector: 'app-company-profile',
  templateUrl: './company-profile.page.html',
  styleUrls: ['./company-profile.page.scss'],
  standalone: false,
})
export class CompanyProfilePage implements OnInit {
  business: any;

  constructor(private businessService: BusinessService) { }

  ngOnInit() {
    this.loadBusiness();
  }

  loadBusiness() {
    // Fetch business data from the service
    this.business = this.businessService.getBusinessDetails();
  }
}
