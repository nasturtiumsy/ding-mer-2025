import { Component } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
  standalone: false,
})
export class AppComponent {
  showMenu: boolean = false;
  constructor(private router: Router) {
    // Listen to route changes
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        // Show menu only if the current route is NOT 'login'
        this.showMenu = !event.url.includes('login');
      }
    });
  }

  // Function to navigate to different pages
  navigateTo(page: string) {
    this.router.navigate([page]);
  }

  // Logout function (basic implementation for now)
  logout() {
    console.log('User logged out');
    this.router.navigate(['login']); // Redirect to the login page
  }
}
