import { Component, OnInit } from '@angular/core';
import { Chart } from 'chart.js/auto';
import { TransactionService } from '../services/transaction.service';
import { SettlementService } from '../services/settlement.service';
import { BranchService } from '../services/branch.service';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
  standalone: false,
})
export class HomePage implements OnInit {
  // Metrics
  totalTransactions = 0;
  grossAmount = 0;
  netAmount = 0;

  // Date Range Filters
  selectedDateRange: string = 'today'; // Default to today
  displayDateRange: string = 'Today'; // Displayed date range

  // Branches
  branches: any[] = [];
  selectedBranch: string = 'all'; // Default to "All Branches"

  // Transaction Types
  transactionTypes = [
    { value: 'all', label: 'All' },
    { value: 'Sale', label: 'Sale' },
    { value: 'Refund', label: 'Refund' },
  ];
  dateRangeOptions = [
    { value: 'today', label: 'Today' },
    { value: 'yesterday', label: 'Yesterday' },
    { value: 'last_week', label: 'Last Week' },
    { value: 'last_month', label: 'Last Month' }
  ];
  selectedTransactionType: string = 'all'; // Default to "All"

  // Notifications
  notifications: any[] = [];

  // Chart Data
  revenueData = {
    labels: [] as string[],
    datasets: [
      {
        label: 'Total Revenue',
        data: [] as number[],
        backgroundColor: '#FFE800', // Bright yellow
      },
    ],
  };

  private chart: any;

  constructor(
    private transactionService: TransactionService,
    private settlementService: SettlementService,
    private branchService: BranchService
  ) { }

  ngOnInit() {
    this.loadInitialData();
  }

  loadInitialData() {
    // Fetch branches
    this.branches = this.branchService.getBranches();

    // Apply filters
    this.applyFilters();

    // Fetch transactions
    const transactions = this.transactionService.getTransactions();

    // Generate notifications for the latest 5 transactions
    this.notifications = transactions
      .slice() // Create a shallow copy of the array
      .sort((a, b) => new Date(b.Date).getTime() - new Date(a.Date).getTime()) // Sort by date (newest first)
      .slice(0, 5) // Take the latest 5 transactions
      .map((txn) => {
        return {
          id: txn.TransactionID,
          type: txn.TransactionType,
          status: txn.TransactionStatus,
          phoneNumber: txn.PhoneNumber,
          amount: txn.TransactionType === 'Refund' ? -txn.Amount : txn.Amount, // Negate refund amounts
          timeAgo: this.calculateTimeAgo(new Date(txn.Date)), // Calculate time elapsed
        };
      });
  }

  applyFilters() {
    // Fetch transactions based on filters
    const transactions = this.transactionService.getTransactions();

    // Initialize startDate and endDate
    const today = new Date();
    let startDate = new Date(today); // Default to today
    let endDate = new Date(today);   // Default to today

    // Apply date range filter
    switch (this.selectedDateRange) {
      case 'today':
        // Set startDate and endDate to today
        startDate.setHours(0, 0, 0, 0); // Start of today
        endDate.setHours(23, 59, 59, 999); // End of today
        break;
      case 'yesterday':
        // Set startDate and endDate to yesterday
        const yesterday = new Date(today);
        yesterday.setDate(today.getDate() - 1);
        startDate = new Date(yesterday);
        startDate.setHours(0, 0, 0, 0); // Start of yesterday
        endDate = new Date(yesterday);
        endDate.setHours(23, 59, 59, 999); // End of yesterday
        break;
      case 'last_week':
        // Set startDate to 7 days ago and endDate to today
        startDate = new Date(today);
        startDate.setDate(today.getDate() - 7);
        break;
      case 'last_month':
        // Set startDate to the first day of last month and endDate to the last day of last month
        startDate = new Date(today.getFullYear(), today.getMonth() - 1, 1); // First day of last month
        endDate = new Date(today.getFullYear(), today.getMonth(), 0);       // Last day of last month
        break;
    }

    // Filter transactions
    const filteredTransactions = transactions.filter((txn) => {
      const txnDate = new Date(txn.Date);

      // Exclude failed transactions
      if (txn.TransactionStatus === 'Failed') return false;

      // Apply date range filter
      if (txnDate < startDate || txnDate > endDate) return false;

      // Apply branch filter
      if (this.selectedBranch !== 'all' && txn.BranchID !== this.selectedBranch) return false;

      // Apply transaction type filter
      if (this.selectedTransactionType !== 'all' && txn.TransactionType !== this.selectedTransactionType) return false;

      return true;
    });

    // Update metrics
    this.totalTransactions = filteredTransactions.length;
    this.grossAmount = filteredTransactions.reduce((sum, txn) => {
      if (txn.TransactionType === 'Refund') {
        return sum - txn.Amount; // Subtract refund amount
      }
      return sum + txn.Amount; // Add sale amount
    }, 0);

    this.netAmount = this.settlementService.calculateNetAmount(this.grossAmount);

    // Update chart data
    this.updateChartData(filteredTransactions, startDate, endDate);

    // Render or update the chart
    if (this.chart) {
      this.chart.destroy(); // Destroy existing chart instance
    }
    this.renderRevenueChart();

    // Update displayed date range
    this.updateDisplayDateRange(startDate, endDate);
  }

  updateChartData(transactions: any[], startDate: Date, endDate: Date) {
    if (this.selectedDateRange === 'today' || this.selectedDateRange === 'yesterday') {
      // Display transactions by hour
      const hours = Array.from({ length: 24 }, (_, i) => `${i.toString().padStart(2, '0')}:00`);
      const hourlyData = Array(24).fill(0);

      transactions.forEach((txn) => {
        const txnHour = new Date(txn.Date).getHours();
        hourlyData[txnHour] += txn.TransactionType === 'Refund' ? -txn.Amount : txn.Amount;
      });

      this.revenueData.labels = hours;
      this.revenueData.datasets[0].data = hourlyData;
    } else {
      // Display transactions by date
      const dates = this.generateDateRange(startDate, endDate);
      const dailyData = dates.map((date) => {
        const dailyTxns = transactions.filter((txn) => new Date(txn.Date).toDateString() === date.toDateString());
        return dailyTxns.reduce((sum, txn) => {
          if (txn.TransactionType === 'Refund') {
            return sum - txn.Amount; // Subtract refund amount
          }
          return sum + txn.Amount; // Add sale amount
        }, 0);
      });

      this.revenueData.labels = dates.map((date) => date.toLocaleDateString('en-GB')); // DD/MM/YYYY format
      this.revenueData.datasets[0].data = dailyData;
    }
  }

  generateDateRange(startDate: Date, endDate: Date): Date[] {
    const dates = [];
    let currentDate = new Date(startDate);
    while (currentDate <= endDate) {
      dates.push(new Date(currentDate));
      currentDate.setDate(currentDate.getDate() + 1);
    }
    return dates;
  }

  updateDisplayDateRange(startDate: Date, endDate: Date) {
    if (this.selectedDateRange === 'today') {
      this.displayDateRange = `Today (${startDate.toLocaleDateString('en-GB')})`;
    } else if (this.selectedDateRange === 'yesterday') {
      this.displayDateRange = `Yesterday (${startDate.toLocaleDateString('en-GB')})`;
    } else if (this.selectedDateRange === 'last_week') {
      this.displayDateRange = `Last Week (${startDate.toLocaleDateString('en-GB')} - ${endDate.toLocaleDateString('en-GB')})`;
    } else if (this.selectedDateRange === 'last_month') {
      this.displayDateRange = `Last Month (${startDate.toLocaleDateString('en-GB')} - ${endDate.toLocaleDateString('en-GB')})`;
    }
  }

  renderRevenueChart() {
    const ctx = document.getElementById('revenueChart') as HTMLCanvasElement;
    this.chart = new Chart(ctx, {
      type: 'bar',
      data: this.revenueData,
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: false,
          },
        },
        scales: {
          x: {
            beginAtZero: true,
          },
          y: {
            beginAtZero: true,
          },
        },
      },
    });
  }
  calculateTimeAgo(date: Date): string {
    const now = new Date();
    const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);

    if (diffInSeconds < 60) {
      return `${diffInSeconds} sec ago`;
    } else if (diffInSeconds < 3600) {
      const minutes = Math.floor(diffInSeconds / 60);
      return `${minutes} min ago`;
    } else if (diffInSeconds < 86400) {
      const hours = Math.floor(diffInSeconds / 3600);
      return `${hours} hour${hours > 1 ? 's' : ''} ago`;
    } else {
      const days = Math.floor(diffInSeconds / 86400);
      return `${days} day${days > 1 ? 's' : ''} ago`;
    }
  }
}