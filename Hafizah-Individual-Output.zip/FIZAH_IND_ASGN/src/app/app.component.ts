import { Component } from '@angular/core';
@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
  standalone: false,
})
export class AppComponent {
  public appPages = [
    { 
	title: 'Dashboard', 
	url: '/dashboard', 
	icon: 'speedometer' 
	},
    { 
	title: 'Branches', 
	url: '/branch', 
	icon: 'storefront'
	},
    { 
	title: 'Statement', 
	url: '/statement', 
	icon: 'document-text' 
	},
    { 
	title: 'Terminal', 
	url: '/terminal', 
	icon: 'call' 
	},
    { 
	title: 'Settings', 
	url: '/settings', 
	icon: 'settings' 
	},
  ];
  constructor() {}
}
