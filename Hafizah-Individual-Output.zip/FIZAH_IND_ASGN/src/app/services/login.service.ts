import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';

@Injectable({
  providedIn: 'root',
})
export class LoginService implements CanActivate {
  isLoggedIn = false;

  constructor(private router: Router) {}

  authenticate(username: string, password: string): boolean {
    if (username === 'admin' && password === 'password') {
      this.isLoggedIn = true;
      this.router.navigate(['/dashboard']);
      return true;
    } else {
      alert('Invalid credentials');
      return false;
    }
  }

  logout() {
    this.isLoggedIn = false;
    this.router.navigate(['/login']);
  }

  canActivate(): boolean {
    if (this.isLoggedIn) {
      return true;
    } else {
      this.router.navigate(['/login']);
      return false;
    }
  }
}
