import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-qrcode',
  templateUrl: './qrcode.page.html',
  styleUrls: ['./qrcode.page.scss'],
  standalone: false,
})
export class QrcodePage implements OnInit {

  constructor() { }
  biz = { name: "ALEAF APPAREL" };
  ngOnInit() {
  }

}
