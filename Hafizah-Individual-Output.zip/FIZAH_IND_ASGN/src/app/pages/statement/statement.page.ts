import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-statement',
  templateUrl: './statement.page.html',
  styleUrls: ['./statement.page.scss'],
  standalone: false,
})
export class StatementPage implements OnInit {

  // Static full data
  data = [
    {
      reference: 'ABCXXXX12345',
      branch: 'Gadong',
      fromDate: '2025-01-02',
      toDate: '2025-02-01',
    },
    {
      reference: 'DEFXXXX67890',
      branch: 'Kulapis',
      fromDate: '2025-01-02',
      toDate: '2025-02-01',
    },
  ];

  // Data to be shown
  filteredData = [...this.data];

  // Variables
  fromDate: string = '';
  toDate: string = '';
  searchTerm: string = '';

  constructor() { }

  ngOnInit() { }

  // When 'From Date' is selected
  setFromDate(event: any) {
    this.fromDate = event.detail.value;
  }

  // When 'To Date' is selected
  setToDate(event: any) {
    this.toDate = event.detail.value;
  }

  // On clicking GO button
  submitDates() {
    this.applyFilters();
  }

  // When typing in the search bar
  onSearchChange(event: any) {
    this.searchTerm = event.detail.value;
    this.applyFilters();
  }

  // Apply both search and date filters
  applyFilters() {
    this.filteredData = this.data.filter(entry => {
      const matchesReference = entry.reference.toLowerCase().includes(this.searchTerm.toLowerCase());
      
      const fromDateValid = this.fromDate ? new Date(entry.fromDate) >= new Date(this.fromDate) : true;
      const toDateValid = this.toDate ? new Date(entry.toDate) <= new Date(this.toDate) : true;

      return matchesReference && fromDateValid && toDateValid;
    });
  }
}
