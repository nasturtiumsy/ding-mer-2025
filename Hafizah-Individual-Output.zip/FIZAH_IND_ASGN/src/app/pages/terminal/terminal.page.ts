import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-terminal',
  templateUrl: './terminal.page.html',
  styleUrls: ['./terminal.page.scss'],
  standalone: false,
})
export class TerminalPage implements OnInit {

  constructor() { }
  branch1manager = {
    name: 'Amy',
    no: '+673 8902130'
  };

  branch1bus = {
    id: 1,
    phoneNo: ['+673 8647670', '+673 8123456', '+673 8543210']
  };
  
  branch2manager = {
    name: 'Alif',
    no: '+673 8234567'
  };

  branch2bus = {
    id: 1,
    phoneNo: ['+673 8917297', '+673 8765189']
  };
  
  ngOnInit() {
  }

}
