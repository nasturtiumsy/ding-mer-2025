import { Component, OnInit } from '@angular/core';
import { LoginService } from 'src/app/services/login.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-settings',
  templateUrl: './settings.page.html',
  styleUrls: ['./settings.page.scss'],
  standalone: false,
})
export class SettingsPage implements OnInit {

  constructor(private LoginService: LoginService, private router: Router) { }

  ngOnInit() {}

  logout() {
    this.LoginService.logout();
    this.router.navigate(['/login']);
  }

}
