import { Component, OnInit, ViewChild } from '@angular/core';
import { BaseChartDirective } from 'ng2-charts';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.page.html',
  styleUrls: ['./dashboard.page.scss'],
  standalone: false,
})
export class DashboardPage implements OnInit {

  @ViewChild(BaseChartDirective) chart?: BaseChartDirective;

  // Transactions data
  transactions = [
    { id: 1101, date: '2025-01-02', amount: 150.0, type: 'debit' },
    { id: 1102, date: '2025-01-02', amount: 200.0, type: 'credit' },
    { id: 1103, date: '2025-02-01', amount: 75.0, type: 'debit' },
    { id: 1104, date: '2025-02-02', amount: 300.0, type: 'credit' },
    { id: 1105, date: '2025-02-03', amount: 50.0, type: 'debit' },
  ];

  // Summary metrics
  summary = {
    totalDebit: 0,
    totalCredit: 0,
  };

  // Chart configuration
  barChartOptions = {
    responsive: true,
    scales: {
      x: { beginAtZero: true, grid: { display: false } },
      y: { beginAtZero: true, grid: { display: false } },
    },
    plugins: {
      legend: { display: false },
    },
  };

  barChartLabels = ['Total Debit', 'Total Credit'];
  barChartLegend = false;

  barChartData = [
    {
      data: [0, 0],
      label: '',
      backgroundColor: [] as (string | CanvasGradient)[],
    },
  ];

  fromDate: string = '';
  toDate: string = '';
  filteredTransactions: any[] = [];

  ngOnInit() {
    this.filteredTransactions = [...this.transactions];
    this.calculateSummary();
  }

  calculateSummary() {
    let totalDebit = 0;
    let totalCredit = 0;

    this.filteredTransactions.forEach(transaction => {
      if (transaction.type === 'debit') {
        totalDebit += transaction.amount;
      } else if (transaction.type === 'credit') {
        totalCredit += transaction.amount;
      }
    });

    this.summary.totalDebit = totalDebit;
    this.summary.totalCredit = totalCredit;

    this.barChartData[0].data = [totalDebit, totalCredit];

    const chartCanvas = document.querySelector('canvas');
    if (chartCanvas) {
      const ctx = chartCanvas.getContext('2d');
      if (ctx) {
        const gradient1 = ctx.createLinearGradient(0, 0, 0, 400);
        gradient1.addColorStop(0, '#ff00e1');
        gradient1.addColorStop(1, '#700063');

        const gradient2 = ctx.createLinearGradient(0, 0, 0, 400);
        gradient2.addColorStop(0, '#FFC029');
        gradient2.addColorStop(1, '#FD9F24');

        this.barChartData[0].backgroundColor = [gradient1, gradient2];
      }
    }

    this.chart?.update();
  }

  filterByDateRange() {
    if (!this.fromDate || !this.toDate) {
      this.filteredTransactions = [...this.transactions];
      this.calculateSummary();
      return;
    }

    const fromDate = new Date(this.fromDate).toISOString().slice(0, 10);
    const toDate = new Date(this.toDate).toISOString().slice(0, 10);

    this.filteredTransactions = this.transactions.filter(transaction => {
      const transactionDate = transaction.date;
      return transactionDate >= fromDate && transactionDate <= toDate;
    });

    this.calculateSummary();
  }

  onFromDateChange(event: any) {
    this.fromDate = event.detail.value;
  }

  onToDateChange(event: any) {
    this.toDate = event.detail.value;
  }
}