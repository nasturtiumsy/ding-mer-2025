import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { RouterModule } from '@angular/router';
import { DashboardPage } from './dashboard.page';
import { NgChartsModule } from 'ng2-charts';
import { FormsModule } from '@angular/forms';
import { Component, OnInit, ViewChild } from '@angular/core';
import { BaseChartDirective } from 'ng2-charts';


@NgModule({
  declarations: [DashboardPage],
  imports: [
    CommonModule,
    IonicModule,
	FormsModule,
    RouterModule.forChild([
      {
        path: '',
        component: DashboardPage,
      },
    ]),
    NgChartsModule,
  ],
})
export class DashboardPageModule {}
