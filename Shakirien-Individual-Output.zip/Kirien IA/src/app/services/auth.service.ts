import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private isAuthenticated = new BehaviorSubject<boolean>(false);
  private companyCredentials = {
    email: 'aleafapparel@gmail.com',
    password: 'password123'
  };

  constructor(private router: Router) {
    const isLoggedIn = localStorage.getItem('isLoggedIn');
    if (isLoggedIn === 'true') {
      this.isAuthenticated.next(true);
    }
  }

  login(email: string, password: string): boolean {
    if (email === this.companyCredentials.email && 
        password === this.companyCredentials.password) {
      this.isAuthenticated.next(true);
      localStorage.setItem('isLoggedIn', 'true');
      return true;
    }
    return false;
  }

  logout() {
    this.isAuthenticated.next(false);
    localStorage.removeItem('isLoggedIn');
    this.router.navigate(['/login']);
  }

  isLoggedIn() {
    return this.isAuthenticated.asObservable();
  }

  getCompanyCredentials() {
    return this.companyCredentials;
  }

  changePassword(newPassword: string): boolean {
    if (newPassword && newPassword.trim() !== '') {
      this.companyCredentials.password = newPassword;
      return true;
    }
    return false;
  }
} 