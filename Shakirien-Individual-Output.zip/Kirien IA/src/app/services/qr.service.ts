import { Injectable } from '@angular/core';
import { toDataURL } from 'qrcode';

@Injectable({
  providedIn: 'root'
})
export class QrService {
  constructor() { }

  downloadQrCode(terminalId: string, branchName: string): void {
    const filename = `qr_${branchName.toLowerCase().replace(/\s+/g, '_')}_terminal_${terminalId}.png`;
    
    const terminalInfo = {
      terminalId: terminalId,
      branchName: branchName,
      timestamp: new Date().toISOString()
    };
    
    const qrData = JSON.stringify(terminalInfo);
    
    toDataURL(qrData, { 
      width: 300,
      margin: 1,
      color: {
        dark: '#000000',
        light: '#ffffff'
      }
    })
    .then((url: string) => {
      const link = document.createElement('a');
      link.href = url;
      link.download = filename;
      
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    })
    .catch((err: Error) => {
      console.error('Error generating QR code:', err);
    });
  }
} 