import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../services/auth.service';
import { ToastController } from '@ionic/angular';

@Component({
  selector: 'app-company-profile',
  templateUrl: './company-profile.page.html',
  styleUrls: ['./company-profile.page.scss'],
  standalone: false
})
export class CompanyProfilePage implements OnInit {
  companyCredentials: any;
  isEditingPassword: boolean = false;
  newPassword: string = '';
  confirmPassword: string = '';
  showNewPassword: boolean = false;
  showConfirmPassword: boolean = false;

  constructor(
    private authService: AuthService,
    private toastController: ToastController
  ) {
    this.companyCredentials = this.authService.getCompanyCredentials();
  }

  ngOnInit() {
  }

  toggleNewPassword() {
    this.showNewPassword = !this.showNewPassword;
  }

  toggleConfirmPassword() {
    this.showConfirmPassword = !this.showConfirmPassword;
  }

  startEditingPassword() {
    this.isEditingPassword = true;
    this.newPassword = '';
    this.confirmPassword = '';
    this.showNewPassword = false;
    this.showConfirmPassword = false;
  }

  async savePassword() {
    if (this.newPassword !== this.confirmPassword) {
      const toast = await this.toastController.create({
        message: 'Passwords do not match',
        duration: 2000,
        position: 'bottom',
        color: 'danger'
      });
      toast.present();
      return;
    }

    if (this.authService.changePassword(this.newPassword)) {
      this.isEditingPassword = false;
      this.showNewPassword = false;
      this.showConfirmPassword = false;
      const toast = await this.toastController.create({
        message: 'Password updated successfully',
        duration: 2000,
        position: 'bottom',
        color: 'success'
      });
      toast.present();
    } else {
      const toast = await this.toastController.create({
        message: 'Failed to update password',
        duration: 2000,
        position: 'bottom',
        color: 'danger'
      });
      toast.present();
    }
  }

  cancelEditing() {
    this.isEditingPassword = false;
    this.newPassword = '';
    this.confirmPassword = '';
    this.showNewPassword = false;
    this.showConfirmPassword = false;
  }
}
