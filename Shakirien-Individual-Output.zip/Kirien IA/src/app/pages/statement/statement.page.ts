import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-statement',
  templateUrl: './statement.page.html',
  styleUrls: ['./statement.page.scss'],
  standalone: false
})
export class StatementPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
