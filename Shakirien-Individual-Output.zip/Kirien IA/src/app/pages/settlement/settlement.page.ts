import { Component, OnInit } from '@angular/core';

interface Settlement {
  date: Date;
  amount: number;
  account: string;
}

@Component({
  selector: 'app-settlement',
  templateUrl: './settlement.page.html',
  styleUrls: ['./settlement.page.scss'],
  standalone: false
})
export class SettlementPage implements OnInit {
  settlements: Settlement[] = [
    { date: new Date('2024-04-24'), amount: 1250.00, account: '••• 1234' },
    { date: new Date('2024-04-23'), amount: 980.00, account: '••• 2345' },
    { date: new Date('2024-04-22'), amount: 1080.00, account: '••• 1234' }
  ];

  dateSortAscending: boolean = true;
  amountSortAscending: boolean = true;

  sortByDate() {
    this.dateSortAscending = !this.dateSortAscending;
    this.settlements.sort((a, b) => {
      return this.dateSortAscending ? b.date.getTime() - a.date.getTime() : a.date.getTime() - b.date.getTime();
    });
  }

  sortByAmount() {
    this.amountSortAscending = !this.amountSortAscending;
    this.settlements.sort((a, b) => {
      return this.amountSortAscending ? b.amount - a.amount : a.amount - b.amount;
    });
  }

  constructor() { }

  ngOnInit() {
    this.sortByDate();
  }
}
