import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { SettlementPageRoutingModule } from './settlement-routing.module';

import { SettlementPage } from './settlement.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    SettlementPageRoutingModule
  ],
  declarations: [SettlementPage]
})
export class SettlementPageModule {}
