import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Chart, registerables } from 'chart.js';
import { Router } from '@angular/router';

Chart.register(...registerables);

interface Transaction {
  date: Date;
  description: string;
  amount: number;
  status: 'Completed' | 'Pending';
}

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.page.html',
  styleUrls: ['./dashboard.page.scss'],
  standalone: false,
})
export class DashboardPage implements OnInit {
  @ViewChild('barChart') private chartRef!: ElementRef<HTMLCanvasElement>;
  chart: Chart | undefined;

  totalRevenue: string = '$12,340';
  totalTransactions: number = 267;
  protected Math = Math;
  selectedDateRange: string = 'last7days'; 

  transactions: Transaction[] = [
    // Recent transactions (Last 7 days)
    { date: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000), description: 'Payment', amount: 150.00, status: 'Completed' },
    { date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000), description: 'Payment', amount: 175.00, status: 'Completed' },
    { date: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000), description: 'Refund', amount: -25.00, status: 'Pending' },
    { date: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000), description: 'Payment', amount: 125.00, status: 'Completed' },
    { date: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000), description: 'Payment', amount: 200.00, status: 'Completed' },
    { date: new Date(Date.now() - 6 * 24 * 60 * 60 * 1000), description: 'Withdrawal', amount: -50.00, status: 'Completed' },
    { date: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000), description: 'Payment', amount: 100.00, status: 'Completed' },
    
    // Last 30 days transactions
    { date: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000), description: 'Payment', amount: 150.00, status: 'Completed' },
    { date: new Date(Date.now() - 20 * 24 * 60 * 60 * 1000), description: 'Payment', amount: 125.00, status: 'Completed' },
    { date: new Date(Date.now() - 25 * 24 * 60 * 60 * 1000), description: 'Refund', amount: -25.00, status: 'Completed' },
    { date: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000), description: 'Payment', amount: 175.00, status: 'Completed' },
    { date: new Date(Date.now() - 12 * 24 * 60 * 60 * 1000), description: 'Payment', amount: 100.00, status: 'Completed' },
    { date: new Date(Date.now() - 18 * 24 * 60 * 60 * 1000), description: 'Payment', amount: 150.00, status: 'Completed' },
    { date: new Date(Date.now() - 22 * 24 * 60 * 60 * 1000), description: 'Payment', amount: 125.00, status: 'Completed' },
    { date: new Date(Date.now() - 28 * 24 * 60 * 60 * 1000), description: 'Refund', amount: -25.00, status: 'Completed' },
    
    // Last 6 months transactions
    { date: new Date(Date.now() - 45 * 24 * 60 * 60 * 1000), description: 'Payment', amount: 125.00, status: 'Completed' },
    { date: new Date(Date.now() - 60 * 24 * 60 * 60 * 1000), description: 'Payment', amount: 200.00, status: 'Completed' },
    { date: new Date(Date.now() - 75 * 24 * 60 * 60 * 1000), description: 'Payment', amount: 150.00, status: 'Completed' },
    { date: new Date(Date.now() - 90 * 24 * 60 * 60 * 1000), description: 'Refund', amount: -50.00, status: 'Completed' },
    { date: new Date(Date.now() - 105 * 24 * 60 * 60 * 1000), description: 'Payment', amount: 100.00, status: 'Completed' },
    { date: new Date(Date.now() - 120 * 24 * 60 * 60 * 1000), description: 'Payment', amount: 175.00, status: 'Completed' },
    { date: new Date(Date.now() - 135 * 24 * 60 * 60 * 1000), description: 'Payment', amount: 125.00, status: 'Completed' },
    { date: new Date(Date.now() - 150 * 24 * 60 * 60 * 1000), description: 'Refund', amount: -25.00, status: 'Completed' },
    
    // Older transactions (up to 1 year)
    { date: new Date(Date.now() - 165 * 24 * 60 * 60 * 1000), description: 'Payment', amount: 100.00, status: 'Completed' },
    { date: new Date(Date.now() - 180 * 24 * 60 * 60 * 1000), description: 'Payment', amount: 150.00, status: 'Completed' },
    { date: new Date(Date.now() - 195 * 24 * 60 * 60 * 1000), description: 'Refund', amount: -25.00, status: 'Completed' },
    { date: new Date(Date.now() - 210 * 24 * 60 * 60 * 1000), description: 'Payment', amount: 125.00, status: 'Completed' },
    { date: new Date(Date.now() - 225 * 24 * 60 * 60 * 1000), description: 'Payment', amount: 175.00, status: 'Completed' },
    { date: new Date(Date.now() - 240 * 24 * 60 * 60 * 1000), description: 'Payment', amount: 100.00, status: 'Completed' },
    { date: new Date(Date.now() - 255 * 24 * 60 * 60 * 1000), description: 'Payment', amount: 150.00, status: 'Completed' },
    { date: new Date(Date.now() - 270 * 24 * 60 * 60 * 1000), description: 'Payment', amount: 125.00, status: 'Completed' },
    { date: new Date(Date.now() - 285 * 24 * 60 * 60 * 1000), description: 'Refund', amount: -25.00, status: 'Completed' },
    { date: new Date(Date.now() - 300 * 24 * 60 * 60 * 1000), description: 'Payment', amount: 100.00, status: 'Completed' },
    { date: new Date(Date.now() - 315 * 24 * 60 * 60 * 1000), description: 'Payment', amount: 175.00, status: 'Completed' }
  ];

  constructor(private router: Router) { }

  ngOnInit() {
    this.filterDataByDateRange('last7days');
    setTimeout(() => {
      this.initializeChart();
    }, 100);
  }

  filterDataByDateRange(range: string) {
    this.selectedDateRange = range;
    const today = new Date();
    let startDate: Date;

    switch (range) {
      case 'yesterday':
        startDate = new Date(today);
        startDate.setDate(today.getDate() - 1);
        startDate.setHours(0, 0, 0, 0);
        break;
      case 'last7days':
        startDate = new Date(today);
        startDate.setDate(today.getDate() - 7);
        startDate.setHours(0, 0, 0, 0);
        break;
      case 'last30days':
        startDate = new Date(today);
        startDate.setDate(today.getDate() - 30);
        startDate.setHours(0, 0, 0, 0);
        break;
      case 'last6months':
        startDate = new Date(today);
        startDate.setMonth(today.getMonth() - 6);
        startDate.setHours(0, 0, 0, 0);
        break;
      case '1year':
        startDate = new Date(today);
        startDate.setFullYear(today.getFullYear() - 1);
        startDate.setHours(0, 0, 0, 0);
        break;
      default:
        startDate = new Date(today);
        startDate.setDate(today.getDate() - 7);
        startDate.setHours(0, 0, 0, 0);
    }

    const endDate = new Date(today);
    endDate.setHours(23, 59, 59, 999);

    const filteredTransactions = this.transactions.filter(transaction => 
      transaction.date >= startDate && transaction.date <= endDate
    );

    this.totalTransactions = filteredTransactions.length;

    const revenue = filteredTransactions.reduce((sum, transaction) => sum + transaction.amount, 0);
    this.totalRevenue = '$' + Math.abs(revenue).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });

    this.updateChartData(startDate, endDate);
  }

  updateChartData(startDate: Date, endDate: Date) {
    if (this.chart) {
      const dates: string[] = [];
      const data: number[] = [];
      const currentDate = new Date(startDate);

      const dailyTotals = new Map<string, number>();
      
  
      while (currentDate <= endDate) {
        const dateStr = currentDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
        dailyTotals.set(dateStr, 0);
        currentDate.setDate(currentDate.getDate() + 1);
      }

      this.transactions.forEach(transaction => {
        if (transaction.date >= startDate && transaction.date <= endDate) {
          const dateStr = transaction.date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
          const currentTotal = dailyTotals.get(dateStr) || 0;
          dailyTotals.set(dateStr, currentTotal + transaction.amount);
        }
      });

      dates.push(...dailyTotals.keys());
      data.push(...dailyTotals.values());

      this.chart.data.labels = dates;
      this.chart.data.datasets[0].data = data;
      this.chart.update();
    }
  }

  ionViewDidEnter() {
    if (!this.chart) {
      this.initializeChart();
    }
  }

  private initializeChart() {
    if (this.chartRef && this.chartRef.nativeElement) {
      const ctx = this.chartRef.nativeElement.getContext('2d');
      if (ctx) {
        if (this.chart) {
          this.chart.destroy();
        }

        const today = new Date();
        let startDate = new Date(today);
        startDate.setDate(today.getDate() - 7); 
        startDate.setHours(0, 0, 0, 0);

        const endDate = new Date(today);
        endDate.setHours(23, 59, 59, 999);

        const dates: string[] = [];
        const data: number[] = [];
        const currentDate = new Date(startDate);

        const dailyTotals = new Map<string, number>();
        
        while (currentDate <= endDate) {
          const dateStr = currentDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
          dailyTotals.set(dateStr, 0);
          currentDate.setDate(currentDate.getDate() + 1);
        }

        this.transactions.forEach(transaction => {
          if (transaction.date >= startDate && transaction.date <= endDate) {
            const dateStr = transaction.date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
            const currentTotal = dailyTotals.get(dateStr) || 0;
            dailyTotals.set(dateStr, currentTotal + transaction.amount);
          }
        });

        dates.push(...dailyTotals.keys());
        data.push(...dailyTotals.values());

        const maxValue = Math.max(...data);
        const yAxisMax = Math.ceil(maxValue / 500) * 500;

        this.chart = new Chart(ctx, {
          type: 'line',
          data: {
            labels: dates,
            datasets: [{
              data: data,
              label: 'Revenue',
              borderColor: '#FFD900',
              borderWidth: 2,
              fill: true,
              backgroundColor: 'rgba(255, 217, 0, 0.1)',
              tension: 0.4,
              pointRadius: 0,
              pointHoverRadius: 6,
              pointHoverBackgroundColor: '#FFD900',
              pointHoverBorderColor: '#fff',
              pointHoverBorderWidth: 2,
            }]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            layout: {
              padding: {
                top: 10,
                right: 10,
                left: 10,
                bottom: 0
              }
            },
            scales: {
              y: {
                min: 0,
                max: 300,
                border: {
                  display: false
                },
                grid: {
                  color: '#f0f0f0',
                  drawTicks: false
                },
                ticks: {
                  stepSize: 50,
                  font: {
                    size: 12,
                    family: "'Inter', system-ui, sans-serif",
                    weight: 'normal'
                  },
                  color: '#666',
                  padding: 10,
                  callback: (value) => {
                    return '$' + value.toLocaleString();
                  }
                }
              },
              x: {
                border: {
                  display: false
                },
                grid: {
                  display: false
                },
                ticks: {
                  font: {
                    size: 12,
                    family: "'Inter', system-ui, sans-serif",
                    weight: 'normal'
                  },
                  color: '#666',
                  maxRotation: 0
                }
              }
            },
            plugins: {
              legend: {
                display: false
              },
              tooltip: {
                backgroundColor: 'white',
                titleColor: '#333',
                titleFont: {
                  size: 13,
                  weight: 'bold',
                  family: "'Inter', system-ui, sans-serif"
                },
                bodyColor: '#666',
                bodyFont: {
                  size: 12,
                  family: "'Inter', system-ui, sans-serif"
                },
                padding: 12,
                borderColor: 'rgba(0,0,0,0.05)',
                borderWidth: 1,
                displayColors: false,
                callbacks: {
                  title: (items) => items[0].label || '',
                  label: (context) => '$' + context.parsed.y.toLocaleString()
                }
              }
            },
            interaction: {
              intersect: false,
              mode: 'index'
            }
          }
        });

        setTimeout(() => {
          this.chart?.resize();
        }, 0);
      }
    }
  }

  logout() {
    localStorage.clear();
    this.router.navigate(['/login']);
  }
}
