import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-branch',
  templateUrl: './branch.page.html',
  styleUrls: ['./branch.page.scss'],
  standalone: false
})
export class BranchPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
