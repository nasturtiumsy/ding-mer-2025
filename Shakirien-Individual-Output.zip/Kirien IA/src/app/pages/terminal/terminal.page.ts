import { Component, OnInit } from '@angular/core';
import { QrService } from '../../services/qr.service';

@Component({
  selector: 'app-terminal',
  templateUrl: './terminal.page.html',
  styleUrls: ['./terminal.page.scss'],
  standalone: false
})
export class TerminalPage implements OnInit {
  terminals = [
    {
      id: '1',
      name: 'Kulapis Branch',
      manager: '+673 8647670',
      phone2: '+673 8647670'
    },
    {
      id: '2',
      name: 'Gadong Branch',
      manager: '+673 8212345',
      phone2: '+673 8887722'
    }
  ];

  constructor(private qrService: QrService) { }

  ngOnInit() {
  }

  downloadQrCode(terminalId: string, branchName: string) {
    this.qrService.downloadQrCode(terminalId, branchName);
  }
}
