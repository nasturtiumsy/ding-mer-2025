import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
  },
  {
    path: 'login',
    loadChildren: () => import('./pages/login/login.module').then( m => m.LoginPageModule)
  },
  {
    path: 'dashboard',
    loadChildren: () => import('./pages/dashboard/dashboard.module').then(m => m.DashboardPageModule)
  },
  {
    path: 'statement',
    loadChildren: () => import('./pages/statement/statement.module').then(m => m.StatementPageModule)
  },
  {
    path: 'settlement',
    loadChildren: () => import('./pages/settlement/settlement.module').then(m => m.SettlementPageModule)
  },
  {
    path: 'branch',
    loadChildren: () => import('./pages/branch/branch.module').then(m => m.BranchPageModule)
  },
  {
    path: 'terminal',
    loadChildren: () => import('./pages/terminal/terminal.module').then(m => m.TerminalPageModule)
  },
  {
    path: 'company-profile',
    loadChildren: () => import('./pages/company-profile/company-profile.module').then(m => m.CompanyProfilePageModule)
  }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {}
