import { Component } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';
import { AuthService } from './services/auth.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  standalone: false,
})
export class AppComponent {
  public appPages = [
    { title: 'Dashboard', url: '/dashboard', icon: 'grid-outline' },
    { title: 'Statement', url: '/statement', icon: 'document-text-outline' },
    { title: 'Settlement', url: '/settlement', icon: 'card-outline' },
    { title: 'Branch', url: '/branch', icon: 'business-outline' },
    { title: 'Terminal', url: '/terminal', icon: 'phone-portrait-outline' },
    { title: 'Company Profile', url: '/company-profile', icon: 'briefcase-outline' }
  ];

  isLoginPage = false;
  isAuthenticated = false;

  constructor(private router: Router, private authService: AuthService) {
   
    this.router.events.pipe(
      filter(event => event instanceof NavigationEnd)
    ).subscribe((event: any) => {
      this.isLoginPage = event.url === '/login';
    });

    this.authService.isLoggedIn().subscribe(
      (isLoggedIn: boolean) => {
        this.isAuthenticated = isLoggedIn;
        if (!isLoggedIn && !this.isLoginPage) {
          this.router.navigate(['/login']);
        }
      }
    );
  }

  logout() {
    this.authService.logout();
  }
}
