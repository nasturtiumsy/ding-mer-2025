import { Component, OnInit } from '@angular/core';
import { Chart } from 'chart.js/auto';
import { SupabaseService } from '../services/supabase.service';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
  standalone: false,
})
export class HomePage implements OnInit {
  // Metrics
  totalTransactions = 0;
  grossAmount = 0;
  netAmount = 0;

  // Date Range Filters
  selectedDateRange: string = 'today'; // Default to today
  displayDateRange: string = 'Today'; // Displayed date range

  // Branches
  branches: any[] = [];
  selectedBranch: string = 'all'; // Default to "All Branches"

  // Transaction Types
  transactionTypes = [
    { value: 'all', label: 'All' },
    { value: 'Sale', label: 'Sale' },
    { value: 'Refund', label: 'Refund' },
  ];

  dateRangeOptions = [
    { value: 'today', label: 'Today' },
    { value: 'yesterday', label: 'Yesterday' },
    { value: 'last_week', label: 'Last Week' },
    { value: 'last_month', label: 'Last Month' },
  ];

  selectedTransactionType: string = 'all'; // Default to "All"

  // Notifications
  notifications: any[] = [];

  // Chart Data
  revenueData = {
    labels: [] as string[],
    datasets: [
      {
        label: 'Total Revenue',
        data: [] as number[],
        backgroundColor: '#FFE800', // Bright yellow
      },
    ],
  };

  private chart: any;

  constructor(private supabaseService: SupabaseService) { }

  ngOnInit() {
    this.loadInitialData();
  }

  private cachedTransactions: any[] = [];

  async loadInitialData() {
    try {
      // Fetch branches
      const branchesResponse = await this.supabaseService.getBranches();
      if (branchesResponse.error) {
        console.error('Error fetching branches:', branchesResponse.error);
      } else {
        this.branches = branchesResponse.data; // Extract the 'data' property
      }

      // Fetch transactions and cache them
      const transactionsResponse = await this.supabaseService.getTransactions();
      if (transactionsResponse.error) {
        console.error('Error fetching transactions:', transactionsResponse.error);
      } else {
        this.cachedTransactions = transactionsResponse.data; // Extract the 'data' property
      }

      // Generate notifications for the latest 5 transactions
      this.notifications = this.cachedTransactions
        .slice() // Create a shallow copy of the array
        .sort((a: any, b: any) => new Date(b.date).getTime() - new Date(a.date).getTime()) // Sort by date (newest first)
        .slice(0, 5) // Take the latest 5 transactions
        .map((txn: any) => ({
          id: txn.transaction_id,
          type: txn.transaction_type,
          status: txn.transaction_status,
          phoneNumber: txn.phone_number,
          amount: txn.transaction_type === 'Refund' ? -txn.amount : txn.amount, // Negate refund amounts
          timeAgo: this.calculateTimeAgo(new Date(txn.date)), // Calculate time elapsed
        }));

      console.log('Notifications:', this.notifications);

      // Apply initial filters to populate metrics, chart, and filtered transactions
      await this.applyFilters();
    } catch (error) {
      console.error('Error loading initial data:', error);
    }
  }

  async applyFilters() {
    try {
      // Use cached transactions instead of fetching again
      const transactions = this.cachedTransactions;

      // Initialize startDate and endDate
      const today = new Date();
      let startDate = new Date(today); // Default to today
      let endDate = new Date(today); // Default to today

      // Apply date range filter
      switch (this.selectedDateRange) {
        case 'today':
          startDate.setHours(0, 0, 0, 0); // Start of today
          endDate.setHours(23, 59, 59, 999); // End of today
          break;
        case 'yesterday':
          const yesterday = new Date(today);
          yesterday.setDate(today.getDate() - 1);
          startDate = new Date(yesterday);
          startDate.setHours(0, 0, 0, 0); // Start of yesterday
          endDate = new Date(yesterday);
          endDate.setHours(23, 59, 59, 999); // End of yesterday
          break;
        case 'last_week':
          startDate = new Date(today);
          startDate.setDate(today.getDate() - 7);
          break;
        case 'last_month':
          startDate = new Date(today.getFullYear(), today.getMonth() - 1, 1); // First day of last month
          endDate = new Date(today.getFullYear(), today.getMonth(), 0); // Last day of last month
          break;
      }

      // Filter transactions
      const filteredTransactions = transactions.filter((txn: any) => {
        const txnDate = new Date(txn.date);
        // Exclude failed transactions
        if (txn.transaction_status === 'Failed') return false;
        // Apply date range filter
        if (txnDate < startDate || txnDate > endDate) return false;
        // Apply branch filter
        if (this.selectedBranch !== 'all' && txn.branch_id !== this.selectedBranch) return false;
        // Apply transaction type filter
        if (this.selectedTransactionType !== 'all' && txn.transaction_type !== this.selectedTransactionType) return false;
        return true;
      });

      // Update metrics
      this.totalTransactions = filteredTransactions.length;
      this.grossAmount = filteredTransactions.reduce((sum: number, txn: any) => {
        if (txn.transaction_type === 'Refund') {
          return sum - txn.amount; // Subtract refund amount
        }
        return sum + txn.amount; // Add sale amount
      }, 0);

      this.netAmount = this.calculateNetAmount(this.grossAmount);

      // Update chart data
      this.updateChartData(filteredTransactions, startDate, endDate);

      // Render or update the chart
      if (this.chart) {
        this.chart.destroy(); // Destroy existing chart instance
      }
      this.renderRevenueChart();

      // Update displayed date range
      this.updateDisplayDateRange(startDate, endDate);
    } catch (error) {
      console.error('Error applying filters:', error);
    }

  }

  calculateNetAmount(grossAmount: number): number {
    // Example calculation: Deduct a fixed percentage as fees
    const processingFeeRate = 0.025; // 2.5%
    return grossAmount * (1 - processingFeeRate);
  }

  updateChartData(transactions: any[], startDate: Date, endDate: Date) {
    if (this.selectedDateRange === 'today' || this.selectedDateRange === 'yesterday') {
      // Display transactions by hour
      const hours = Array.from({ length: 24 }, (_, i) => `${i.toString().padStart(2, '0')}:00`);
      const hourlyData = Array(24).fill(0);
      transactions.forEach((txn) => {
        const txnHour = new Date(txn.date).getHours();
        hourlyData[txnHour] += txn.transaction_type === 'Refund' ? -txn.amount : txn.amount;
      });
      this.revenueData.labels = hours;
      this.revenueData.datasets[0].data = hourlyData;
    } else {
      // Display transactions by date
      const dates = this.generateDateRange(startDate, endDate);
      const dailyData = dates.map((date) => {
        const dailyTxns = transactions.filter((txn) => new Date(txn.date).toDateString() === date.toDateString());
        return dailyTxns.reduce((sum, txn) => {
          if (txn.transaction_type === 'Refund') {
            return sum - txn.amount; // Subtract refund amount
          }
          return sum + txn.amount; // Add sale amount
        }, 0);
      });
      this.revenueData.labels = dates.map((date) => date.toLocaleDateString('en-GB')); // DD/MM/YYYY format
      this.revenueData.datasets[0].data = dailyData;
    }
  }

  generateDateRange(startDate: Date, endDate: Date): Date[] {
    const dates = [];
    let currentDate = new Date(startDate);
    while (currentDate <= endDate) {
      dates.push(new Date(currentDate));
      currentDate.setDate(currentDate.getDate() + 1);
    }
    return dates;
  }

  updateDisplayDateRange(startDate: Date, endDate: Date) {
    if (this.selectedDateRange === 'today') {
      this.displayDateRange = `Today (${startDate.toLocaleDateString('en-GB')})`;
    } else if (this.selectedDateRange === 'yesterday') {
      this.displayDateRange = `Yesterday (${startDate.toLocaleDateString('en-GB')})`;
    } else if (this.selectedDateRange === 'last_week') {
      this.displayDateRange = `Last Week (${startDate.toLocaleDateString('en-GB')} - ${endDate.toLocaleDateString('en-GB')})`;
    } else if (this.selectedDateRange === 'last_month') {
      this.displayDateRange = `Last Month (${startDate.toLocaleDateString('en-GB')} - ${endDate.toLocaleDateString('en-GB')})`;
    }
  }

  renderRevenueChart() {
    const ctx = document.getElementById('revenueChart') as HTMLCanvasElement;
    this.chart = new Chart(ctx, {
      type: 'bar',
      data: this.revenueData,
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: false,
          },
        },
        scales: {
          x: {
            beginAtZero: true,
          },
          y: {
            beginAtZero: true,
          },
        },
      },
    });
  }

  calculateTimeAgo(date: Date): string {
    const now = new Date();
    const txnDate = new Date(date);

    // Check if the transaction date is in the future
    if (txnDate > now) {
      return 'In the future'; // Or any other appropriate message
    }

    // Calculate the difference in milliseconds
    const diffInMs = now.getTime() - txnDate.getTime();
    const diffInSeconds = Math.floor(diffInMs / 1000); // Convert to seconds

    if (diffInSeconds < 60) {
      return `${diffInSeconds} second${diffInSeconds !== 1 ? 's' : ''} ago`;
    } else if (diffInSeconds < 3600) {
      const minutes = Math.floor(diffInSeconds / 60);
      return `${minutes} minute${minutes !== 1 ? 's' : ''} ago`;
    } else if (diffInSeconds < 86400) {
      const hours = Math.floor(diffInSeconds / 3600);
      return `${hours} hour${hours !== 1 ? 's' : ''} ago`;
    } else {
      const days = Math.floor(diffInSeconds / 86400);
      return `${days} day${days !== 1 ? 's' : ''} ago`;
    }
  }
}