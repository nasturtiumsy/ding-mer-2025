import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from './services/auth.service'; // Import AuthService

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
  standalone: false,
})
export class AppComponent implements OnInit {
  public isLoggedIn: boolean = false; // Initial login status
  public currentUser: any = null; // Store the current user's details

  public appPages = [
    { title: 'Dashboard', url: '/home', icon: 'speedometer', requiresAuth: true },
    { title: 'Branches', url: '/branch', icon: 'storefront', requiresAuth: true },
    { title: 'Statement', url: '/statement', icon: 'document-text', requiresAuth: true },
    { title: 'Settlement', url: '/settlement', icon: 'wallet', requiresAuth: true },
    { title: 'Terminal', url: '/terminal', icon: 'call', requiresAuth: true },
    { title: 'Company Profile', url: '/company-profile', icon: 'settings', requiresAuth: true },
  ];

  constructor(private router: Router, private authService: AuthService) { }

  ngOnInit() {
    // Subscribe to login status changes
    this.authService.isLoggedIn$.subscribe(async (isLoggedIn) => {
      this.isLoggedIn = isLoggedIn;

      if (isLoggedIn) {
        // Fetch the current user's details
        this.currentUser = await this.authService.getCurrentUserDetails();
      } else {
        this.currentUser = null; // Clear user details on logout

        // Redirect to login if not authenticated
        if (!this.router.url.includes('/login')) {
          this.router.navigate(['/login']);
        }
      }
    });
  }

  // Logout function
  async logout() {
    if (confirm('Are you sure you want to log out?')) {
      this.authService.logout(); // Call logout method from AuthService
      this.router.navigate(['/login']); // Redirect to the login page
    }
  }
}