import { Component, OnInit } from '@angular/core';
import { SupabaseService } from 'src/app/services/supabase.service';

@Component({
  selector: 'app-branch',
  templateUrl: './branch.page.html',
  styleUrls: ['./branch.page.scss'],
  standalone: false,
})
export class BranchPage implements OnInit {
  branches: any[] = [];

  constructor(private supabaseService: SupabaseService) {}

  ngOnInit() {
    this.fetchBranches();
  }

  async fetchBranches() {
    const { data, error } = await this.supabaseService.client
      .from('branches')
      .select('*');

    if (error) {
      console.error('Error fetching branches:', error);
    } else {
      this.branches = data;
    }
  }
}
