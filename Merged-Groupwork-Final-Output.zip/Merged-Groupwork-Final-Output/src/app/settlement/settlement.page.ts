import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { SettlementService } from '../services/settlement.service';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';

interface Settlement {
  settlement_id: string;
  date: string;
  time: string;
  bankAccount: string;
  reference: string;
  amount: number;
  merchant_id?: string;
}

@Component({
  selector: 'app-settlement',
  templateUrl: './settlement.page.html',
  styleUrls: ['./settlement.page.scss'],
  standalone: false
})
export class SettlementPage implements OnInit {
  filterForm: FormGroup;
  filteredSettlements: Settlement[] = [];
  isStartDatePickerOpen = false;
  isEndDatePickerOpen = false;
  isLoading = false;

  constructor(
    private fb: FormBuilder,
    private settlementService: SettlementService
  ) {
    this.filterForm = this.fb.group({
      startDate: new FormControl(''),
      endDate: new FormControl(''),
      searchTerm: new FormControl('')
    });
  }

  ngOnInit() {
    this.setupSearchListener();
    this.loadAllSettlements();
  }

  setupSearchListener() {
    this.searchTerm.valueChanges
      .pipe(debounceTime(300), distinctUntilChanged())
      .subscribe(() => {
        this.applyFilters();
      });
  }

  
  get startDate() { return this.filterForm.get('startDate') as FormControl; }
  get endDate() { return this.filterForm.get('endDate') as FormControl; }
  get searchTerm() { return this.filterForm.get('searchTerm') as FormControl; }

  applyFilters() {
    this.isLoading = true;
    const { startDate, endDate, searchTerm } = this.filterForm.value;

    this.settlementService.getSettlements(startDate, endDate, searchTerm)
      .subscribe({
        next: ({ data, error }) => {
          if (error) {
            console.error('Error fetching settlements:', error);
            this.filteredSettlements = [];
            return;
          }

          this.filteredSettlements = (data || []).map((item: any): Settlement => ({
            settlement_id: item.settlement_id,
            date: item.date,
            time: item.time,
            bankAccount: item.bank_account,
            reference: item.reference?.toString() || '',
            amount: Number(item.amount),
            merchant_id: item.merchant_id
          }));
        },
        error: (err) => {
          console.error('Error in settlement service:', err);
          this.filteredSettlements = [];
        },
        complete: () => {
          this.isLoading = false;
        }
      });
  }

  exportToExcel() {
    if (this.filteredSettlements.length === 0) {
      console.warn('No settlements to export.');
      return;
    }

    const worksheet = XLSX.utils.json_to_sheet(this.filteredSettlements);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Settlements');

    const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
    const blob = new Blob([excelBuffer], { type: 'application/octet-stream' });
    saveAs(blob, 'settlements_export.xlsx');
  }

  openStartDatePicker() {
    this.isStartDatePickerOpen = true;
  }

  openEndDatePicker() {
    this.isEndDatePickerOpen = true;
  }

  onStartDateChange(event: CustomEvent) {
    const value = event.detail?.value;
    if (value) {
      const formatted = new Date(value).toISOString().split('T')[0];
      this.startDate.setValue(formatted);
      this.applyFilters();
    }
    this.isStartDatePickerOpen = false;
  }

  onEndDateChange(event: CustomEvent) {
    const value = event.detail?.value;
    if (value) {
      const formatted = new Date(value).toISOString().split('T')[0];
      this.endDate.setValue(formatted);
      this.applyFilters();
    }
    this.isEndDatePickerOpen = false;
  }

  loadAllSettlements() {
    this.isLoading = true;
    this.settlementService.getSettlements('', '', '')
      .subscribe({
        next: ({ data, error }) => {
          if (error) {
            console.error('Error fetching settlements:', error);
            this.filteredSettlements = [];
            return;
          }

          this.filteredSettlements = (data || []).map((item: any): Settlement => ({
            settlement_id: item.settlement_id,
            date: item.date,
            time: item.time,
            bankAccount: item.bank_account,
            reference: item.reference?.toString() || '',
            amount: Number(item.amount),
            merchant_id: item.merchant_id
          }));
        },
        error: (err) => {
          console.error('Error in settlement service:', err);
          this.filteredSettlements = [];
        },
        complete: () => {
          this.isLoading = false;
        }
      });
  }

  clearFilters() {
    this.filterForm.reset();
    this.loadAllSettlements();
  }
}
