import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

@Injectable({
  providedIn: 'root',
})
export class NoAuthGuard implements CanActivate {
  constructor(private authService: AuthService, private router: Router) {}

  canActivate(): boolean {
    if (this.authService.isLoggedIn()) {
      // Redirect logged-in users to the company profile page
      this.router.navigate(['/company-profile']);
      return false;
    }

    // Allow access to the login page for non-logged-in users
    return true;
  }
}