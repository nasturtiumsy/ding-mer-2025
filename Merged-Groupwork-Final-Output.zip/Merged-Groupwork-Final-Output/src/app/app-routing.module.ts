import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './guard/auth.guard';
import { NoAuthGuard } from './guard/no-auth-guard.guard';

const routes: Routes = [
  {
    path: 'home',
    loadChildren: () => import('./home/home.module').then((m) => m.HomePageModule),
    canActivate: [AuthGuard], // Protect this route for logged-in users only
  },
  {
    path: 'statement',
    loadChildren: () => import('./statement/statement.module').then((m) => m.StatementPageModule),
    canActivate: [AuthGuard],
  },
  {
    path: 'settlement',
    loadChildren: () => import('./settlement/settlement.module').then((m) => m.SettlementPageModule),
    canActivate: [AuthGuard],
  },
  {
    path: 'branch',
    loadChildren: () => import('./branch/branch.module').then((m) => m.BranchPageModule),
    canActivate: [AuthGuard],
  },
  {
    path: 'terminal',
    loadChildren: () => import('./terminal/terminal.module').then((m) => m.TerminalPageModule),
    canActivate: [AuthGuard],
  },
  {
    // Updated to accept 'terminalId' as a parameter
    path: 'qrcode/:terminalId',
    loadChildren: () => import('./qrcode/qrcode.module').then(m => m.QrcodePageModule),
    canActivate: [AuthGuard],
  },
  //{
  //   path: 'terminal',
  //   loadChildren: () => import('./qrcode/qrcode.module').then((m) => m.QrcodePageModule),
  //   canActivate: [AuthGuard],
  // },
  {
    path: 'company-profile',
    loadChildren: () => import('./company-profile/company-profile.module').then((m) => m.CompanyProfilePageModule),
    canActivate: [AuthGuard],
  },
  {
    path: 'login',
    loadChildren: () => import('./login/login.module').then((m) => m.LoginPageModule),
    canActivate: [NoAuthGuard], // Prevent logged-in users from accessing the login page
  },
  {
    path: '',
    redirectTo: '/login', // Default route redirects to login
    pathMatch: 'full',
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules }), // Preload all modules for better performance
  ],
  exports: [RouterModule],
})
export class AppRoutingModule { }