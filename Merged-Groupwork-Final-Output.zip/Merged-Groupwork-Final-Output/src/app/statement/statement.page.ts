import { Component, OnInit } from '@angular/core';
import * as XLSX from 'xlsx';
import { SupabaseService, Branch, Terminal } from '../services/supabase.service';

@Component({
  selector: 'app-statement',
  templateUrl: './statement.page.html',
  styleUrls: ['./statement.page.scss'],
  standalone: false,
})
export class StatementPage implements OnInit {
  // Metrics
  totalSales = 0;
  reversedSales = 0;

  // Date Range Filters
  today = new Date().toISOString().split('T')[0]; // Today's date in YYYY-MM-DD format
  startDate: string = this.today; // Default to today
  endDate: string = this.today;   // Default to today

  // Branches and Terminals
  branches: Branch[] = [];
  terminals: Terminal[] = [];
  selectedBranch: string = 'all'; // Default to "All Branches"
  selectedTerminal: string = 'all'; // Default to "All Terminals"

  // Search Query
  searchQuery: string = '';

  // Transactions
  transactions: any[] = [];
  filteredTransactions: any[] = [];

  // Sorting
  sortColumn: string = 'date'; // Default sorting column
  sortOrder: string = 'desc';   // Default sorting order (descending)

  // Pagination Variables
  currentPage: number = 1; // Current page number
  pageSize: number = 10;   // Number of transactions per page
  totalPages: number = 1;  // Total number of pages
  paginatedTransactions: any[] = []; // Transactions for the current page

  constructor(private supabaseService: SupabaseService) { }

  async ngOnInit() {
    await this.loadInitialData();
  }

  async loadInitialData() {
    try {
      // Fetch branches and terminals from Supabase
      const { data: branchesData, error: branchesError } = await this.supabaseService.getBranches();
      if (branchesError) throw branchesError;
      this.branches = branchesData;

      const { data: terminalsData, error: terminalsError } = await this.supabaseService.getTerminals();
      if (terminalsError) throw terminalsError;
      this.terminals = terminalsData;

      // Fetch transactions from Supabase
      const { data: transactionsData, error: transactionsError } = await this.supabaseService.getTransactions();
      if (transactionsError) throw transactionsError;

      this.transactions = transactionsData.map((txn) => ({
        ...txn,
        amount: txn.transaction_type === 'Refund' ? -txn.amount : txn.amount, // Make refunds negative
      }));

      // Apply initial filters
      this.applyFilters();
    } catch (error) {
      console.error('Error loading initial data:', error);
    }
  }

  applyFilters() {
    // Filter transactions based on criteria
    const filteredTransactions = this.transactions
      .filter((txn) => {
        const txnDate = new Date(txn.date);

        // Apply date range filter
        if (this.startDate && txnDate < new Date(this.startDate)) return false;
        if (this.endDate && txnDate > new Date(this.endDate)) return false;

        // Apply branch filter
        if (this.selectedBranch !== 'all' && txn.branch_id !== this.selectedBranch) return false;

        // Apply terminal filter
        if (this.selectedTerminal !== 'all' && txn.terminal_id !== this.selectedTerminal) return false;

        // Apply search filter
        const searchableFields = [
          txn.transaction_id,
          this.getBranchName(txn.branch_id),
          this.getTerminalName(txn.terminal_id),
          txn.phone_number,
          Math.abs(txn.amount).toString(),
        ].join(' ').toLowerCase();

        if (this.searchQuery && !searchableFields.includes(this.searchQuery.toLowerCase())) return false;

        return true;
      })
      .map((txn) => ({
        ...txn,
        BranchName: this.getBranchName(txn.branch_id), // Add BranchName to the transaction object
        TerminalName: this.getTerminalName(txn.terminal_id), // Add TerminalName to the transaction object
      }));

    // Sort transactions
    this.filteredTransactions = this.sortTransactions(filteredTransactions);

    // Calculate metrics
    this.totalSales = filteredTransactions.reduce((sum, txn) => {
      if (txn.transaction_type === 'Sale') {
        return sum + txn.amount;
      }
      return sum;
    }, 0);

    this.reversedSales = filteredTransactions.reduce((sum, txn) => {
      if (txn.transaction_type === 'Refund') {
        return sum + txn.amount; // Already negative for refunds
      }
      return sum;
    }, 0);

    // Pagination Logic
    this.totalPages = Math.ceil(this.filteredTransactions.length / this.pageSize);
    this.updatePaginatedTransactions();
  }

  sortTransactions(transactions: any[]): any[] {
    return [...transactions].sort((a, b) => {
      const valA = a[this.sortColumn];
      const valB = b[this.sortColumn];

      if (this.sortOrder === 'asc') {
        return typeof valA === 'string' ? valA.localeCompare(valB) : valA - valB;
      } else {
        return typeof valA === 'string' ? valB.localeCompare(valA) : valB - valA;
      }
    });
  }

  sort(column: string) {
    if (this.sortColumn === column) {
      // Cycle through sorting orders: asc -> desc -> asc
      this.sortOrder = this.sortOrder === 'asc' ? 'desc' : 'asc';
    } else {
      // Set new column and reset to ascending
      this.sortColumn = column;
      this.sortOrder = 'asc';
    }

    this.applyFilters();
  }

  getSortIndicator(column: string): string {
    if (this.sortColumn === column) {
      return this.sortOrder === 'asc' ? '↑' : '↓';
    }
    return '';
  }

  updatePaginatedTransactions() {
    const start = (this.currentPage - 1) * this.pageSize;
    const end = start + this.pageSize;
    this.paginatedTransactions = this.filteredTransactions.slice(start, end);
  }

  previousPage() {
    if (this.currentPage > 1) {
      this.currentPage--;
      this.updatePaginatedTransactions();
    }
  }

  nextPage() {
    if (this.currentPage < this.totalPages) {
      this.currentPage++;
      this.updatePaginatedTransactions();
    }
  }

  // Helper Functions
  getBranchName(branchID: string): string {
    const branch = this.branches.find((b) => b.branch_id === branchID);
    return branch ? branch.branch_name : 'Unknown Branch';
  }

  getTerminalName(terminalID: string): string {
    const terminal = this.terminals.find((t) => t.terminal_id === terminalID);
    return terminal ? terminal.terminal_name : 'Unknown Terminal';
  }

  downloadExcel() {
    const worksheetData = [
      ['Date', 'Time', 'Branch', 'Terminal', 'Phone Number', 'Reference', 'Amount ($)'], // Table headers
      ...this.filteredTransactions.map((txn) => [
        txn.date,
        txn.time,
        this.getBranchName(txn.branch_id),
        this.getTerminalName(txn.terminal_id),
        txn.phone_number,
        txn.transaction_id,
        txn.amount.toFixed(2),
      ]),
    ];

    const worksheet = XLSX.utils.aoa_to_sheet(worksheetData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Transactions');
    XLSX.writeFile(workbook, 'transaction_report.xlsx');
  }




}


