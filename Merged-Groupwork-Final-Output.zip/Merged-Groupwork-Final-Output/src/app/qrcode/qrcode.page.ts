import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { SupabaseService } from 'src/app/services/supabase.service';
import * as QRCode from 'qrcode'; // Import the qrcode library

@Component({
  selector: 'app-qrcode',
  templateUrl: './qrcode.page.html',
  styleUrls: ['./qrcode.page.scss'],
  standalone: false,
})
export class QrcodePage implements OnInit {
  terminalId!: string; // Use '!' to indicate that it will be assigned later
  qrCodeDataUrl: string | null = null; // Store the generated QR code as a data URL
  merchantName: string | null = null; // Merchant name
  merchantLogoUrl: string | null = null; // Merchant logo URL

  constructor(
    private activatedRoute: ActivatedRoute,
    private supabaseService: SupabaseService
  ) { }

  ngOnInit() {
    this.activatedRoute.paramMap.subscribe((params) => {
      this.terminalId = params.get('terminalId')!;
      if (this.terminalId) {
        this.fetchQRCodeData();
      }
    });
  }

  async fetchQRCodeData() {
    const { data, error } = await this.supabaseService.client
      .from('qr_code')
      .select('qr_image, merchant_id')
      .eq('terminal_id', this.terminalId)
      .single();

    if (error) {
      console.error('Error fetching QR code data:', error);
      return;
    }

    if (data && data.qr_image) {
      try {
        this.qrCodeDataUrl = await QRCode.toDataURL(data.qr_image); 
      } catch (err) {
        console.error('Error generating QR code:', err);
      }
    }

    this.fetchMerchantDetails(data.merchant_id);
  }

  async fetchMerchantDetails(merchantId: string) {
    const { data, error } = await this.supabaseService.client
      .from('merchant_profile')
      .select('merchant_name, image_link')
      .eq('merchant_id', merchantId)
      .single();

    if (error) {
      console.error('Error fetching merchant details:', error);
      return;
    }

    this.merchantName = data ? data.merchant_name : 'Unknown Merchant';
    this.merchantLogoUrl = data ? data.image_link : 'assets/default-merchant-logo.png'; // Default logo if none found
  }

  /**
   * Downloads the QR code image.
   */
  downloadQRCode() {
    if (!this.qrCodeDataUrl) {
      console.error('QR code data URL is not available.');
      return;
    }

    const link = document.createElement('a');
    link.href = this.qrCodeDataUrl;
    link.download = 'qrcode.png';
    link.click();
  }
}
