import { Component, OnInit } from '@angular/core';
import { SupabaseService } from '../services/supabase.service';
import { ToastController } from '@ionic/angular';
import * as bcrypt from 'bcryptjs';

@Component({
  selector: 'app-company-profile',
  templateUrl: './company-profile.page.html',
  styleUrls: ['./company-profile.page.scss'],
  standalone: false,
})
export class CompanyProfilePage implements OnInit {
  companyCredentials: any = {}; // To store merchant data
  isEditingPassword: boolean = false;
  newPassword: string = '';
  confirmPassword: string = '';
  showNewPassword: boolean = false;
  showConfirmPassword: boolean = false;

  constructor(
    private supabaseService: SupabaseService,
    private toastController: ToastController
  ) {}

  ngOnInit() {
    this.fetchCompanyProfile();
  }

  async fetchCompanyProfile() {
    const merchantId = localStorage.getItem('merchantId');
    if (!merchantId) {
      this.showToast('User not logged in');
      return;
    }

    const { data, error } = await this.supabaseService.client
      .from('merchant_profile')
      .select('*')
      .eq('merchant_id', merchantId);

    if (error || !data || data.length === 0) {
      this.showToast('Failed to fetch company profile');
      return;
    }

    this.companyCredentials = data[0]; // Assign the fetched data to companyCredentials
  }

  toggleNewPassword() {
    this.showNewPassword = !this.showNewPassword;
  }

  toggleConfirmPassword() {
    this.showConfirmPassword = !this.showConfirmPassword;
  }

  startEditingPassword() {
    this.isEditingPassword = true;
    this.newPassword = '';
    this.confirmPassword = '';
    this.showNewPassword = false;
    this.showConfirmPassword = false;
  }

  async savePassword() {
    // Validate password requirements
    const validationMessage = this.validatePassword(this.newPassword);
    if (validationMessage) {
      this.showToast(validationMessage);
      return;
    }

    // Check if passwords match
    if (this.newPassword !== this.confirmPassword) {
      this.showToast('Passwords do not match');
      return;
    }

    // Hash the new password
    const hashedPassword = await bcrypt.hash(this.newPassword, 10);
    const merchantId = localStorage.getItem('merchantId');
    if (!merchantId) {
      this.showToast('User not logged in');
      return;
    }

    // Update the password in the database
    const { error } = await this.supabaseService.client
      .from('merchant_profile')
      .update({ password: hashedPassword })
      .eq('merchant_id', merchantId);

    if (error) {
      this.showToast('Failed to update password');
      return;
    }

    // Success
    this.isEditingPassword = false;
    this.showToast('Password updated successfully');
  }

  cancelEditing() {
    this.isEditingPassword = false;
    this.newPassword = '';
    this.confirmPassword = '';
    this.showNewPassword = false;
    this.showConfirmPassword = false;
  }

  private validatePassword(password: string): string | null {
    const minLength = 8;
    const hasUpperCase = /[A-Z]/.test(password);
    const hasLowerCase = /[a-z]/.test(password);
    const hasNumbers = /[0-9]/.test(password);
    const hasSpecialChars = /[!@#$%^&*(),.?":{}|<>]/.test(password);

    if (password.length < minLength) {
      return `Password must be at least ${minLength} characters long.`;
    }
    if (!hasUpperCase) {
      return 'Password must contain at least one uppercase letter.';
    }
    if (!hasLowerCase) {
      return 'Password must contain at least one lowercase letter.';
    }
    if (!hasNumbers) {
      return 'Password must contain at least one number.';
    }
    if (!hasSpecialChars) {
      return 'Password must contain at least one special character (e.g., @, #, $).';
    }

    return null; // Password meets all requirements
  }

  private async showToast(message: string) {
    const toast = await this.toastController.create({
      message,
      duration: 2000,
      position: 'bottom',
      color: 'danger',
    });
    toast.present();
  }
}