import { Component, OnInit } from '@angular/core';
import { SupabaseService } from 'src/app/services/supabase.service';

@Component({
  selector: 'app-terminal',
  templateUrl: './terminal.page.html',
  styleUrls: ['./terminal.page.scss'],
  standalone: false,
})
export class TerminalPage implements OnInit {
  terminals: any[] = [];
  branches: any[] = [];
  employees: any[] = []; 

  constructor(private supabaseService: SupabaseService) { }

  ngOnInit() {
    this.fetchTerminals();
    this.fetchBranches();
    this.fetchEmployees();
  }

  async fetchTerminals() {
    const { data, error } = await this.supabaseService.client
      .from('terminals')
      .select('*');

    if (error) {
      console.error('Error fetching terminals:', error);
      return;
    }

    this.terminals = data;
  }

  async fetchBranches() {
    const { data, error } = await this.supabaseService.client
      .from('branches')
      .select('*');

    if (error) {
      console.error('Error fetching branches:', error);
      return;
    }

    this.branches = data;
  }

  async fetchEmployees() {
    const { data, error } = await this.supabaseService.client
      .from('employees')
      .select('*');

    if (error) {
      console.error('Error fetching employees:', error);
      return;
    }

    this.employees = data;
  }

  getBranchName(branchId: number): string {
    const branch = this.branches.find(b => b.branch_id === branchId);
    return branch ? branch.branch_name : 'Unknown Branch';
  }

  getEmployeesForTerminal(terminalId: string): any[] {
    return this.employees.filter(employee => employee.terminal_id === terminalId);
  }
}

