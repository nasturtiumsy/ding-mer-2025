import { Component } from '@angular/core';
import { SupabaseService } from '../../services/supabase.service';
import { ToastController, ModalController } from '@ionic/angular';
import * as bcrypt from 'bcryptjs'; // Import bcrypt for password hashing

@Component({
  selector: 'app-forgot-password-modal',
  templateUrl: './forgot-password-modal.component.html',
  styleUrls: ['./forgot-password-modal.component.scss'],
  standalone: false,
})
export class ForgotPasswordModalComponent {
  email: string = '';
  otp: string = '';
  newPassword: string = '';
  confirmPassword: string = '';
  generatedOtp: string = '';
  showOtpInput: boolean = false;
  showPasswordReset: boolean = false;
  otpGeneratedTime: number = 0; // Track when the OTP was generated
  remainingTime: number = 0; // Remaining time for the OTP in seconds
  timerInterval: any; // To store the setInterval reference

  // Password visibility toggles
  showNewPassword: boolean = false;
  showConfirmPassword: boolean = false;

  constructor(
    private supabaseService: SupabaseService,
    private toastController: ToastController,
    private modalController: ModalController
  ) {}

  async sendOtp() {
    const { data, error } = await this.supabaseService.client
      .from('merchant_profile')
      .select('*')
      .eq('email', this.email);

    if (error || !data || data.length === 0) {
      this.showToast('No account found with this email');
      return;
    }

    // Generate a random 6-digit OTP
    this.generatedOtp = Math.floor(100000 + Math.random() * 900000).toString();
    this.otpGeneratedTime = Date.now(); // Record the time when OTP is generated
    console.log('Generated OTP:', this.generatedOtp); // Simulate sending OTP via email
    this.showOtpInput = true;

    // Start the countdown timer
    this.startTimer();

    this.showToast('OTP sent to your email');
  }

  startTimer() {
    const otpExpirationTime = this.otpGeneratedTime + 3 * 60 * 1000; // OTP expires after 3 minutes
    this.remainingTime = Math.max(0, Math.floor((otpExpirationTime - Date.now()) / 1000)); // Initial remaining time

    // Update the timer every second
    this.timerInterval = setInterval(() => {
      this.remainingTime = Math.max(0, Math.floor((otpExpirationTime - Date.now()) / 1000));
      if (this.remainingTime <= 0) {
        clearInterval(this.timerInterval); // Stop the timer when it reaches zero
      }
    }, 1000);
  }

  async verifyOtp() {
    const currentTime = Date.now();
    const otpExpirationTime = this.otpGeneratedTime + 3 * 60 * 1000; // OTP expires after 3 minutes

    if (currentTime > otpExpirationTime) {
      this.showToast('OTP has expired. Please request a new one.');
      return;
    }

    if (this.otp === this.generatedOtp) {
      this.showPasswordReset = true;
      this.showToast('OTP verified successfully');
    } else {
      this.showToast('Invalid OTP');
    }
  }

  async resetPassword() {
    // Validate password requirements
    const validationMessage = this.validatePassword(this.newPassword);
    if (validationMessage) {
      this.showToast(validationMessage);
      return;
    }

    if (this.newPassword !== this.confirmPassword) {
      this.showToast('Passwords do not match');
      return;
    }

    // Hash the new password using bcrypt
    const hashedPassword = await bcrypt.hash(this.newPassword, 10);

    const { error } = await this.supabaseService.client
      .from('merchant_profile')
      .update({ password: hashedPassword }) // Save the hashed password
      .eq('email', this.email);

    if (error) {
      this.showToast('Failed to reset password');
      return;
    }

    this.showToast('Password reset successfully');
    this.closeModal();
  }

  toggleNewPassword() {
    this.showNewPassword = !this.showNewPassword; // Toggle visibility of the new password field
  }

  toggleConfirmPassword() {
    this.showConfirmPassword = !this.showConfirmPassword; // Toggle visibility of the confirm password field
  }

  private validatePassword(password: string): string | null {
    const minLength = 8;
    const hasUpperCase = /[A-Z]/.test(password);
    const hasLowerCase = /[a-z]/.test(password);
    const hasNumbers = /[0-9]/.test(password);
    const hasSpecialChars = /[!@#$%^&*(),.?":{}|<>]/.test(password);

    if (password.length < minLength) {
      return `Password must be at least ${minLength} characters long.`;
    }
    if (!hasUpperCase) {
      return 'Password must contain at least one uppercase letter.';
    }
    if (!hasLowerCase) {
      return 'Password must contain at least one lowercase letter.';
    }
    if (!hasNumbers) {
      return 'Password must contain at least one number.';
    }
    if (!hasSpecialChars) {
      return 'Password must contain at least one special character (e.g., @, #, $).';
    }

    return null; // Password meets all requirements
  }

  private async showToast(message: string) {
    const toast = await this.toastController.create({
      message,
      duration: 2000,
      position: 'bottom',
      color: 'danger',
    });
    toast.present();
  }

  async closeModal() {
    clearInterval(this.timerInterval); // Clear the timer when the modal is closed
    await this.modalController.dismiss(); // Close the modal using ModalController
  }
}