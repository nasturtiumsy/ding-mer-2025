import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ToastController, ModalController } from '@ionic/angular';
import { ForgotPasswordModalComponent } from '../components/forgot-password-modal/forgot-password-modal.component';
import { AuthService } from '../services/auth.service'; // Import AuthService

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
  standalone: false,
})
export class LoginPage {
  email: string = '';
  password: string = '';
  showPassword: boolean = false;

  constructor(
    private router: Router,
    private toastController: ToastController,
    private modalController: ModalController,
    private authService: AuthService // Inject AuthService
  ) { }

  togglePasswordVisibility() {
    this.showPassword = !this.showPassword;
  }

  async onLogin() {
    const success = await this.authService.login(this.email, this.password);

    if (!success) {
      this.showToast('Invalid email or password');
      return;
    }

    // Redirect to the dashboard upon successful login
    this.router.navigate(['/home']);
  }

  async openForgotPasswordModal() {
    const modal = await this.modalController.create({
      component: ForgotPasswordModalComponent,
    });
    await modal.present();

    // Optionally, handle modal dismissal events if needed
    const { data, role } = await modal.onDidDismiss();
    if (role === 'success') {
      this.showToast('Password reset successfully');
    }
  }

  private async showToast(message: string) {
    const toast = await this.toastController.create({
      message,
      duration: 2000,
      position: 'bottom',
      color: 'danger',
    });
    toast.present();
  }
}