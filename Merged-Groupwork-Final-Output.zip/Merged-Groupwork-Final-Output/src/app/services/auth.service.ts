import { Injectable } from '@angular/core';
import { SupabaseService } from './supabase.service';
import * as bcrypt from 'bcryptjs';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private isLoggedInSubject = new BehaviorSubject<boolean>(this.isLoggedIn());
  public isLoggedIn$ = this.isLoggedInSubject.asObservable();

  constructor(private supabaseService: SupabaseService) {}

  async login(email: string, password: string): Promise<boolean> {
    const { data, error } = await this.supabaseService.client
      .from('merchant_profile')
      .select('*')
      .eq('email', email);

    if (error || !data || data.length === 0) {
      return false;
    }

    const merchant = data[0];
    const isPasswordValid = await bcrypt.compare(password, merchant.password);

    if (!isPasswordValid) {
      return false;
    }

    localStorage.setItem('isLoggedIn', 'true');
    localStorage.setItem('merchantId', merchant.merchant_id);
    this.isLoggedInSubject.next(true);

    return true;
  }

  logout() {
    localStorage.removeItem('isLoggedIn');
    localStorage.removeItem('merchantId');
    this.isLoggedInSubject.next(false);
  }

  isLoggedIn(): boolean {
    return localStorage.getItem('isLoggedIn') === 'true';
  }

  getMerchantId(): string | null {
    return localStorage.getItem('merchantId');
  }

  // Fetch the current user's details from the database
  async getCurrentUserDetails() {
    const merchantId = this.getMerchantId();
    if (!merchantId) {
      return null;
    }

    const { data, error } = await this.supabaseService.client
      .from('merchant_profile')
      .select('*')
      .eq('merchant_id', merchantId)
      .single();

    if (error) {
      console.error('Error fetching user details:', error);
      return null;
    }

    return data; // Return the user's details
  }
}