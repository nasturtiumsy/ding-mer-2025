import { Injectable } from '@angular/core';
import { from, Observable } from 'rxjs';
import { SupabaseService } from './supabase.service';

interface SettlementDB {
  date: string;
  time: string;
  bank_account: string;
  reference: bigint;
  amount: bigint;
  merchant_id: string;
  settlement_id: string;
}

interface Settlement {
  date: string;
  time: string;
  bankAccount: string;
  reference: string;
  amount: number;
  merchant_id: string;
  settlement_id: string;
}

@Injectable({
  providedIn: 'root'
})
export class SettlementService {
  constructor(private supabaseService: SupabaseService) {}

  getSettlements(startDate: string, endDate: string, searchTerm: string): Observable<any> {
    const supabase = this.supabaseService.client;

    let query = supabase.from('settlement').select('*');

    console.log('Filter parameters:', { startDate, endDate, searchTerm });

    if (startDate) {
      const formattedStartDate = this.formatToIsoDate(startDate);
      console.log('Filtering from date:', formattedStartDate);
      query = query.gte('date', formattedStartDate);
    }

    if (endDate) {
      const formattedEndDate = this.formatToIsoDate(endDate);
      console.log('Filtering to date:', formattedEndDate);
      query = query.lte('date', formattedEndDate);
    }

    if (searchTerm?.trim()) {
      const trimmed = searchTerm.trim();
      console.log('Searching reference using ilike:', trimmed);
      query = query.ilike('reference', `%${trimmed}%`);
    }

    return from(query);
  }

  private formatToIsoDate(date: string): string {
    const parsed = new Date(date);
    if (isNaN(parsed.getTime())) {
      console.warn('Invalid date passed to formatToIsoDate:', date);
      return '';
    }
    return parsed.toISOString().split('T')[0];
  }
}
