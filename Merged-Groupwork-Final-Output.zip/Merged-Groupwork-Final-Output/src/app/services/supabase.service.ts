import { Injectable } from '@angular/core';
import { createClient, SupabaseClient } from '@supabase/supabase-js';

// Define interfaces for the branch and terminal data
export interface Branch {
  branch_id: string;
  branch_name: string;
}

export interface Terminal {
  terminal_id: string;
  terminal_name: string;
}

@Injectable({
  providedIn: 'root',
})
export class SupabaseService {
  private supabase: SupabaseClient;

  constructor() {
    this.supabase = createClient(
      'https://ekknxqfexfxsmaezbdkw.supabase.co', // Supabase URL
      'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImVra254cWZleGZ4c21hZXpiZGt3Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDUyOTkxODQsImV4cCI6MjA2MDg3NTE4NH0.aMBprZxIv8ILya6qSmKWOQv9UxFDuvKmsoCNlrQkzV0' // Supabase API Key
    );
  }

  get client(): SupabaseClient {
    return this.supabase;
  }

  async getBranches(): Promise<{ data: Branch[]; error: any }> {
    const merchantId = localStorage.getItem('merchantId');
    if (!merchantId) {
      console.error('Merchant ID not found in local storage.');
      return { data: [], error: 'Merchant ID not found' };
    }

    try {
      const { data, error } = await this.supabase
        .from('branches')
        .select('*')
        .eq('merchant_id', merchantId);

      if (error) {
        console.error('Error fetching branches:', error);
        return { data: [], error };
      }

      return { data, error: null };
    } catch (error) {
      console.error('Error in SupabaseService.getBranches:', error);
      return { data: [], error };
    }
  }

  async getTerminals(): Promise<{ data: Terminal[]; error: any }> {
    const merchantId = localStorage.getItem('merchantId');
    if (!merchantId) {
      console.error('Merchant ID not found in local storage.');
      return { data: [], error: 'Merchant ID not found' };
    }

    try {
      const { data, error } = await this.supabase
        .from('terminals')
        .select('*')
        .eq('merchant_id', merchantId);

      if (error) {
        console.error('Error fetching terminals:', error);
        return { data: [], error };
      }

      return { data, error: null };
    } catch (error) {
      console.error('Error in SupabaseService.getTerminals:', error);
      return { data: [], error };
    }
  }

  async getTransactions(): Promise<{ data: any[]; error: any }> {
    const merchantId = localStorage.getItem('merchantId');
    if (!merchantId) {
      console.error('Merchant ID not found in local storage.');
      return { data: [], error: 'Merchant ID not found' };
    }

    try {
      const { data, error } = await this.supabase
        .from('transactions')
        .select('*')
        .eq('merchant_id', merchantId);

      if (error) {
        console.error('Error fetching transactions:', error);
        return { data: [], error };
      }

      return { data, error: null };
    } catch (error) {
      console.error('Error in SupabaseService.getTransactions:', error);
      return { data: [], error };
    }
  }
}