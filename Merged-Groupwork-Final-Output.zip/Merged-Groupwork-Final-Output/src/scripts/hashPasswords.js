const { createClient } = require('@supabase/supabase-js');
const bcrypt = require('bcrypt');

const supabaseUrl = 'https://ekknxqfexfxsmaezbdkw.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImVra254cWZleGZ4c21hZXpiZGt3Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDUyOTkxODQsImV4cCI6MjA2MDg3NTE4NH0.aMBprZxIv8ILya6qSmKWOQv9UxFDuvKmsoCNlrQkzV0';
const supabase = createClient(supabaseUrl, supabaseKey);

async function hashPasswords() {
  const { data: merchants, error } = await supabase.from('merchant_profile').select('*');
  if (error) {
    console.error('Error fetching merchants:', error);
    return;
  }

  for (const merchant of merchants) {
    const hashedPassword = await bcrypt.hash(merchant.password, 10); // Hash password with bcrypt
    const { error: updateError } = await supabase
      .from('merchant_profile')
      .update({ password: hashedPassword })
      .eq('merchant_id', merchant.merchant_id);

    if (updateError) {
      console.error(`Error updating password for merchant ${merchant.merchant_id}:`, updateError);
    } else {
      console.log(`Password updated for merchant ${merchant.merchant_id}`);
    }
  }
}

hashPasswords();